﻿
set feedback off
set define OFF
prompt Deleting t_auth_role_function...
--清空角色权限关联表
DELETE FROM t_auth_role_function;
prompt Deleting t_auth_function...
--清空功能权限表
DELETE FROM t_auth_function;

prompt insert data to T_AUTH_FUNCTION...please wait...
-- ----------------------------
-- Records of t_auth_function
-- ----------------------------
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid) values ('0', '根节点', '0', '根节点', null, '0', 0, null);
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid) values ('101', '基础档案', 'jichudangan', '基础档案功能', null, '1', 0, '0');
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid) values ('101001', '收派标准', 'standard', null, 'page_base_standard.action', '1', 1, '101');
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid) values ('101002', '取派员设置', 'staff:list', null, 'page_base_staff.action', '1', 2, '101');
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid) values ('101002001', '取派员添加', 'staff:add', null, null, '0', 0, '101002');
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid) values ('101003', '区域设置', 'region', null, 'page_base_region.action', '1', 3, '101');
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid) values ('101004', '管理分区', 'subarea', null, 'page_base_subarea.action', '1', 4, '101');
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid) values ('101005', '管理定区/调度排班', 'decidedzone', null, 'page_base_decidedzone.action', '1', 5, '101');
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid) values ('102', '受理', 'shouli', null, null, '1', 1, '0');
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid) values ('102001', '业务受理', 'noticebill', null, 'page_qupai_noticebill_add.action', '1', 0, '102');
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid) values ('102002', '工作单快速录入', 'quickworkordermanage', null, 'page_qupai_quickworkorder.action', '1', 1, '102');
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid) values ('102003', '工作单导入', 'workordermanageimport', null, 'page_qupai_workorderimport.action', '1', 3, '102');
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid) values ('103', '调度', 'diaodu', null, null, '1', 2, '0');
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid) values ('103001', '查台转单', 'changestaff', null, null, '1', 0, '103');
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid) values ('103002', '人工调度', 'personalassign', null, 'page_qupai_diaodu.action', '1', 1, '103');
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid) values ('104', '中转配送流程管理', 'zhongzhuan', null, null, '1', 3, '0');
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid) values ('104001', '工作单审核', 'workordermanagecheck', null, 'workordermanage_list.action', '1', 0, '104');
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid) values ('104002', '查看个人任务', 'personaltask', null, 'page_workflow_personaltask.action', '1', 1, '104');
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid) values ('104003', '查看我的组任务', 'grouptask', null, null, '1', 2, '104');

commit;
prompt insert data ok...

set feedback on
set define on
