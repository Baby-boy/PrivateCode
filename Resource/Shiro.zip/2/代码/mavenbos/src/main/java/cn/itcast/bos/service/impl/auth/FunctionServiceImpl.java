package cn.itcast.bos.service.impl.auth;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.itcast.bos.dao.auth.FunctionDAO;
import cn.itcast.bos.domain.auth.Function;
import cn.itcast.bos.domain.user.User;
import cn.itcast.bos.service.auth.FunctionService;
import cn.itcast.bos.service.base.BaseService;

//功能权限的业务层实现
@Service("functionService")
@Transactional
public class FunctionServiceImpl  extends BaseService implements FunctionService{
	//注入dao
	@Autowired
	private FunctionDAO functionDAO;

	@Override
	public List<Function> findFunctionList() {
		return functionDAO.findAll();
	}

	@Override
	@CacheEvict(value="MenuSpringCache",allEntries=true)
	public void saveFunction(Function function) {
		//这里有两个事情：
		//1.父编号，是否是必须要有(可以在jsp中设置必填，，如果你不设置必填，就在这里判断，如果父节点为空，就认为一级节点)
		//2.主键问题：现在没有主键，需要手动生成：
		
		//分析主键的生成规则
		//先考虑正常：先获取父节点下面的所有子节点的最大的id的值，然后考虑+1
		//但，如果下面没有最大的子节点id的值，当前是第一个，就不能直接+1，得拼接
		//但，考虑，一级节点和二级以下节点，第一个节点规则不一样。
		
		//父节点
		Function parentFunction = function.getFunction();
		
		//定义一个引用：当前节点
		String id=null;
		
		//获取父节点下面的所有子节点最大的id的值
		String maxId=functionDAO.findMaxIdByPId(parentFunction);
		if(StringUtils.isNotBlank(maxId)){
			//当前节点的父节点已经有子节点，直接——+1
			id=String.valueOf(Integer.parseInt(maxId)+1);
		}else{
			//对于父节点是根节点和不是根节点分别处理
			if(parentFunction.getId().equals("0")){
				//根节点，现在要填是一级节点
				id="101";
			}else{
				//父节点+001
				id=parentFunction.getId()+"001";
			}
		}
		
		//主键设置
		function.setId(id);
		//保存功能权限
		functionDAO.save(function);
		
	}

	@Override
	@Cacheable(value="MenuSpringCache",key="#user.id")
	//java 缓存的数据结构 Map结构（key，value）
	//value：缓存的结果
	//key：默认情况下，使用参数对象的地址拼成key（X00ff）
	//发现有问题，如果参数user对象不是一个，则第二次不能从缓存获取，就会从新缓存，但是一个用户，知识对象不一样
	//解决：将key缓存id，手动指定key，不用默认
	public List<Function> findMenuList(User user) {
		//需求分析：查询T_AUTH_FUNCTION数据
		//查询条件：1）是菜单 generatemenu=‘1’
		//2）当前用户有权限：（多表关联查询的语句）
		//3)隐藏：菜单排序
		//考虑超管
		if(user.getUsername().equals("admin")){
			//拥有所有的菜单
			return functionDAO.findByGeneratemenuOrderByZindexAsc("1");
		}else{
//		return functionDAO.findMenuForUser(user);
			return functionDAO.findMenuForUser(user.getId());
		}
		
	}

}
