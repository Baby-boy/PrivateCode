package cn.itcast.bos.auth.realm;

import java.util.List;
import java.util.Set;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import cn.itcast.bos.dao.auth.FunctionDAO;
import cn.itcast.bos.dao.auth.RoleDAO;
import cn.itcast.bos.dao.user.UserDAO;
import cn.itcast.bos.domain.auth.Function;
import cn.itcast.bos.domain.auth.Role;
import cn.itcast.bos.domain.user.User;

//bos系统的realm对象：用来提供权限数据（认证和授权）
@Component("bosRealm")
public class BosRealm extends AuthorizingRealm{
	//注入Ehcache的缓存的区域的名字
	//注入缓存名称
	@Value("BosShiroCache")//注入缓存具体对象的名字,该名字在ehcache.xml中配置的
	public void setSuperAuthenticationCacheName(String authenticationCacheName){
		super.setAuthenticationCacheName(authenticationCacheName);
	}

	
	//注入用户dao
	@Autowired
	private UserDAO userDAO;
	//注入角色dao
	@Autowired
	private RoleDAO roleDAO;
	//注入功能权限dao
	@Autowired
	private FunctionDAO functionDAO;

	@Override
	//提供授权数据
	//默认值null，说明没有数据，授权不通过
	//参数：用户集合
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
		System.out.println("授权开始。。。。。");
		
		//获取当前登录“用户”和用户名字
		//两种取法
		//1)通过工具类获取首长，就是用户
//		User user=(User)SecurityUtils.getSubject().getPrincipal();
		//2)通过传进来的对象(主登录用户--就这一个)
		User user=(User)principals.getPrimaryPrincipal();
		
		//给安全管理器提供AuthorizationInfo对象
		SimpleAuthorizationInfo authorizationInfo =new SimpleAuthorizationInfo();
//		//可以给授权的权限(字符串--数据库或xml配置)
//		authorizationInfo.addStringPermission("user");
//		//给授权的角色
//		authorizationInfo.addRole("operator");
//		return authorizationInfo;
		
		//目标：要根据当前登录用户，查询出其所拥有的角色和权限，给授权信息对象（AuthorizationInfo）
		//对于当前登录用户要考虑两种：超管，普通用户
		if("admin".equals(user.getUsername())){
			//超管(admin)：就默认一定是拥有系统中所有的角色和所有权限，不管是否关联关系
			//所有角色
			List<Role> roleList = roleDAO.findAll();
			for (Role role : roleList) {
				authorizationInfo.addRole(role.getCode());
			}
			//所有权限
			List<Function> functionList = functionDAO.findAll();
			for (Function function : functionList) {
				authorizationInfo.addStringPermission(function.getCode());
			}
		}else{
			//普通用户：必须有关联关系才行（用户和角色，角色和功能权限）
			//根据当前登录用户获取角色
			List<Role> roleList = roleDAO.findByUsers(user);
			for (Role role : roleList) {
				authorizationInfo.addRole(role.getCode());
				//根据当前登录用户获取权限（导航查询）
				Set<Function> functions = role.getFunctions();
				for (Function function : functions) {
					authorizationInfo.addStringPermission(function.getCode());
				}
			}
		}
		
		return authorizationInfo;
	}

	@Override
	//提供认证数据
	//默认值null，说明没有数据，认证不通过
	//参数：腰牌，subject传进去的对象
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
		System.out.println("认证开始。。。。。");
		
		//获取当前的“用户”信息（输入的）
		String username = ((UsernamePasswordToken)token).getUsername();
		
		//目标：根据  用户名   查询出数据库中真实用户对象(用户名和密码)
		User user = userDAO.findByUsername(username);
		
		if(null==user){
			//  用户名不存在
			return null;
		}else{
			//密码不正确，提供AuthenticationInfo对象
			//参数1：首长，认证的用户对象（要放入“session”）
			//参数2：凭证，数据库真实的密码
			//参数3：调用的reaml的名字
			AuthenticationInfo authenticationInfo = new SimpleAuthenticationInfo(user, user.getPassword(), super.getName());
			return authenticationInfo;//给安全管理器（大管家）
		}
		
	}

}
