package cn.itcast.bos.service.user;

import java.util.List;

import cn.itcast.bos.domain.user.User;

//用户操作的业务层接口
public interface UserService {
	
	/**
	 * 
	 * 说明：保存用户
	 * @param user
	 * @author 传智.BoBo老师
	 * @time：2016年10月8日 上午10:53:46
	 */
	public void saveUser(User user);
	
	/**
	 * 
	 * 说明：查询所有用户
	 * @return
	 * @author 传智.BoBo老师
	 * @time：2016年10月8日 上午10:54:29
	 */
	public List<User> findAllUsers();
	
	/**
	 * 
	 * 说明：根据用户名查询出用户
	 * @param username
	 * @return
	 * @author 传智.BoBo老师
	 * @time：2016年10月8日 上午11:22:34
	 */
	public User findByUsername(String username);
	
	/**
	 * 
	 * 说明：根据用户名查询密码
	 * @param username
	 * @return
	 * @author 传智.BoBo老师
	 * @time：2016年10月8日 上午11:35:27
	 */
	public String findPasswordByUsername(String username);
	
	/**
	 * 
	 * 说明：根据用户名和密码来查询用户
	 * @param username
	 * @param password
	 * @return
	 * @author 传智.BoBo老师
	 * @time：2016年10月8日 上午11:42:35
	 */
	public User findUserByUsernameAndPassword(String username,String password);

	/**
	 * 
	 * 说明：登录
	 * @param user
	 * @return
	 * @author 传智.BoBo老师
	 * @time：2016年10月8日 下午3:01:41
	 */
	public User login(User user);

	/**
	 * 
	 * 说明：修改用户密码
	 * @param user
	 * @author 传智.BoBo老师
	 * @time：2016年10月8日 下午5:28:10
	 */
	public void updatePasswordForUser(User user);

	/**
	 * 
	 * 说明：保存用户
	 * @param user
	 * @param roleIds
	 * @author 传智.BoBo老师
	 * @time：2016年10月19日 下午3:54:50
	 */
	public void saveUser(User user, String[] roleIds);

}
