package cn.itcast.bos.dao.auth;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import cn.itcast.bos.domain.auth.Function;
import cn.itcast.bos.domain.user.User;
import java.lang.String;

//功能权限dao
public interface FunctionDAO extends JpaRepository<Function, String>{
	
	//根据父节点查询子节点id最大的值
	@Query("select max(f.id) from Function f where f.function.id=?")
	public String findMaxIdByPId(String pId);
	
	@Query("select max(f.id) from Function f where f.function=?")
	public String findMaxIdByPId(Function function);
	
	
	//查询所有的菜单（给超管用）
	public List<Function> findByGeneratemenuOrderByZindexAsc(String generatemenu);

	//根据用户查询菜单列表
	//hql
	@Query("select f from Function f inner join fetch f.roles r where f.generatemenu='1' and r.users=? order by f.zindex asc")//hql
	public List<Function> findMenuForUser(User user);
	//sql
	@Query(value="SELECT * FROM t_auth_function t1 INNER JOIN t_auth_role_function t2 ON t1.id=t2.function_id INNER JOIN t_auth_user_role t3 ON t2.role_id=t3.role_id WHERE t1.generatemenu='1' AND t3.user_id=? ORDER BY t1.zindex ASC",nativeQuery=true)
	public List<Function> findMenuForUser(String id);

}
