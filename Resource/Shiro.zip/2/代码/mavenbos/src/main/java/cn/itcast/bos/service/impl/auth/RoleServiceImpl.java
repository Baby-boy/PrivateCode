package cn.itcast.bos.service.impl.auth;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.itcast.bos.dao.auth.FunctionDAO;
import cn.itcast.bos.dao.auth.RoleDAO;
import cn.itcast.bos.domain.auth.Function;
import cn.itcast.bos.domain.auth.Role;
import cn.itcast.bos.service.auth.RoleService;
import cn.itcast.bos.service.base.BaseService;

//角色的业务层实现
@Service("roleService")
@Transactional
public class RoleServiceImpl extends BaseService implements RoleService{
	//注入dao
	@Autowired
	private RoleDAO roleDAO;
	//注入功能权限的dao
	@Autowired
	private FunctionDAO functionDAO;

	@Override
	public List<Role> findRoleList() {
		return roleDAO.findAll();
	}

	@Override
	public void saveRole(Role role, String functionIds) {
		//两个业务：
		//1.保存角色
		roleDAO.save(role);
		
		//2.关联 功能权限
		//多表的关系表如何维护？
		//hibernate的方案：建立关系(持久态)即可
		if(null!=functionIds){
			//割
			String[] idArray = functionIds.split(",");
			//循环
			for (String id : idArray) {
				Function function = functionDAO.findOne(id);
				//建立关系
				role.getFunctions().add(function);
				//等快照了。。。
			}
		}
	}

}
