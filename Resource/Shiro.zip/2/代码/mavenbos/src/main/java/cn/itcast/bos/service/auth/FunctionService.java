package cn.itcast.bos.service.auth;

import java.util.List;

import cn.itcast.bos.domain.auth.Function;
import cn.itcast.bos.domain.user.User;

////功能权限的业务层接口
public interface FunctionService {

	/**
	 * 
	 * 说明： 查询所有的功能权限列表
	 * @return
	 * @author 传智.BoBo老师
	 * @time：2016年10月19日 上午10:21:52
	 */
	public List<Function> findFunctionList();

	/**
	 * 
	 * 说明：保存功能权限
	 * @param function
	 * @author 传智.BoBo老师
	 * @time：2016年10月19日 上午10:49:55
	 */
	public void saveFunction(Function function);

	/**
	 * 
	 * 说明：根据登录用户查询菜单功能列表
	 * @param user
	 * @return
	 * @author 传智.BoBo老师
	 * @time：2016年10月19日 下午4:51:27
	 */
	public List<Function> findMenuList(User user);

}
