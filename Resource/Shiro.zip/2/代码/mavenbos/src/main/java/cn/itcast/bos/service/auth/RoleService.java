package cn.itcast.bos.service.auth;

import java.util.List;

import cn.itcast.bos.domain.auth.Role;

//角色的业务层接口
public interface RoleService {

	/**
	 * 
	 * 说明：查询所有角色列表
	 * @return
	 * @author 传智.BoBo老师
	 * @time：2016年10月19日 上午11:33:45
	 */
	public List<Role> findRoleList();

	/**
	 * 
	 * 说明：保存角色（+关联功能权限）
	 * @param role
	 * @param functionIds
	 * @author 传智.BoBo老师
	 * @time：2016年10月19日 下午2:54:36
	 */
	public void saveRole(Role role, String functionIds);

}
