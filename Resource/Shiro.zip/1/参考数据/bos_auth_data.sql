﻿prompt PL/SQL Developer import file
prompt Created on 2016年2月23日 by BoBo
set feedback off
set define off
prompt Loading T_AUTH_FUNCTION...
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid)
values ('1', '取派员操作', 'staff', '取派员的CRUD', null, null, null, null);
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid)
values ('2', '区域操作', 'region', '区域的CRUD', null, null, null, null);
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid)
values ('3', '业务受理', 'noticebill', '添加业务通知单和下单', null, null, null, null);
insert into T_AUTH_FUNCTION (id, name, code, description, page, generatemenu, zindex, pid)
values ('4', '工作单快速录入', 'quickworkorder', '工作单快速录入', null, null, null, null);
commit;
prompt 4 records loaded
prompt Loading T_AUTH_ROLE...
insert into T_AUTH_ROLE (id, name, code, description)
values ('1', '维护人员', 'weihu', '基础数据维护人员');
insert into T_AUTH_ROLE (id, name, code, description)
values ('2', '客服人员', 'kefu', '业务客服受理业务的人员');
commit;
prompt 2 records loaded
prompt Loading T_AUTH_ROLE_FUNCTION...
insert into T_AUTH_ROLE_FUNCTION (role_id, function_id)
values ('1', '1');
insert into T_AUTH_ROLE_FUNCTION (role_id, function_id)
values ('1', '2');
insert into T_AUTH_ROLE_FUNCTION (role_id, function_id)
values ('2', '3');
insert into T_AUTH_ROLE_FUNCTION (role_id, function_id)
values ('2', '4');
commit;
prompt 4 records loaded
prompt Loading T_USER...
insert into T_USER (id, username, password, salary, birthday, gender, station, telephone, remark)
values ('1ewqewe', 'admin', '21232f297a57a5a743894a0e4a801fc3', null, null, null, null, null, null);
insert into T_USER (id, username, password, salary, birthday, gender, station, telephone, remark)
values ('1', 'Jack', 'c4ca4238a0b923820dcc509a6f75849b', null, null, null, null, null, null);
insert into T_USER (id, username, password, salary, birthday, gender, station, telephone, remark)
values ('2', 'Rose', 'c4ca4238a0b923820dcc509a6f75849b', null, null, null, null, null, null);
commit;
prompt 3 records loaded
prompt Loading T_AUTH_USER_ROLE...
insert into T_AUTH_USER_ROLE (user_id, role_id)
values ('1', '1');
insert into T_AUTH_USER_ROLE (user_id, role_id)
values ('2', '2');
commit;
prompt 2 records loaded
set feedback on
set define on
prompt Done.
