package cn.itcast.bos.service.user;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cn.itcast.bos.domain.user.User;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="classpath:applicationContext.xml")
public class UserServiceTest {
	//注入service
	@Autowired
	private UserService userService;

	@Test
	public void testSaveUser() {
		//瞬时态对象
		User user = new User();
		user.setUsername("admin");
		user.setPassword("admin");
		//保存
		userService.saveUser(user);
		
	}

	@Test
	public void testFindAllUsers() {
		List<User> userList = userService.findAllUsers();
		System.out.println(userList);
	}
	
	@Test
	public void testFindByUsername() {
		User user = userService.findByUsername("admin");
		System.out.println(user);
	}
	@Test
	public void testFindPasswordByUsername() {
		String password = userService.findPasswordByUsername("admin");
		System.out.println(password);
	}
	
	@Test
	public void testFindUserByUsernameAndPassword() {
		User user = userService.findUserByUsernameAndPassword("admin", "21232f297a57a5a743894a0e4a801fc3");
		System.out.println(user);
	}
	
	

}
