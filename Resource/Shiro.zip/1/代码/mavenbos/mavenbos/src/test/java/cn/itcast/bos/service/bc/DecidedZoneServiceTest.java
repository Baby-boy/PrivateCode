package cn.itcast.bos.service.bc;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cn.itcast.bos.domain.ws.Customer;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="classpath:applicationContext.xml")
public class DecidedZoneServiceTest {
	//注入bean
	@Autowired
	private DecidedZoneService decidedZoneService;

	@Test
	public void testFindCustomerListNoDecidedZone() {
		List<Customer> customerList = decidedZoneService.findCustomerListNoDecidedZone();
		System.out.println(customerList);
	}

	@Test
	public void testFindCustomerListHasDecidedZone() {
		List<Customer> customerList = decidedZoneService.findCustomerListHasDecidedZone("DQ001");
		System.out.println(customerList);
	}

	@Test
	public void testUpdateCustomerByDecidedZoneId() {
		decidedZoneService.updateCustomerByDecidedZoneId("DQ001", "2,3");
		System.out.println("更新成功！！！");
	}

}
