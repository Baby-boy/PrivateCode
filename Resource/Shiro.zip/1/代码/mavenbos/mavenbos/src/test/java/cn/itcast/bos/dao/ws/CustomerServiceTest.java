package cn.itcast.bos.dao.ws;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.itcast.bos.dao.ws.stub.CustomerService;

public class CustomerServiceTest {
	
	@Test
	public void testCustomerService(){
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		CustomerService customerService= (CustomerService) applicationContext.getBean("customerService");
		
		String result = customerService.operateCustomer("{'opertype':'101'}");
		System.out.println(result);
	}

}
