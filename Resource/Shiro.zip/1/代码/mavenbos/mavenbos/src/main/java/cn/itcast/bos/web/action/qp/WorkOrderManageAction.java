package cn.itcast.bos.web.action.qp;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;

import com.opensymphony.xwork2.ActionContext;

import cn.itcast.bos.domain.qp.WorkOrderManage;
import cn.itcast.bos.service.qp.WorkOrderManageService;
import cn.itcast.bos.web.action.base.BaseAction;

//工作单管理的action
@Controller("workOrderManageAction")
@Scope("prototype")
@ParentPackage("basic-bos")
@Namespace("/")
public class WorkOrderManageAction extends BaseAction<WorkOrderManage>{
	//注入service
	@Autowired
	private WorkOrderManageService workOrderManageService;
	
	//保存工作单
	@Action("workOrderManage_save")
	public String save(){
		Map<String, Object> resultMap = new HashMap<>();
		
		try {
			//调用业务层保存
			workOrderManageService.saveWorkOrderManage(model);
			resultMap.put("result", true);
		} catch (Exception e) {
			e.printStackTrace();
			resultMap.put("result", false);
		}
		//压栈顶
		ActionContext.getContext().getValueStack().push(resultMap);
		return JSON;
	}
	
	//分页列表查询
	@Action("workOrderManage_listPage")
	public String listPage(){
		
		//分页条件bean对象
		Pageable pageable =new PageRequest(page-1, rows);
		
		//获取搜索的内容的参数的值(略)
		
		//查询有两个逻辑：查询所有和全文检索查询
		Page<WorkOrderManage> pageResponse=null;
		//判断：
		if(StringUtils.isNotBlank(conditionName)&&StringUtils.isNotBlank(conditionValue)){
			//全文检索
			pageResponse=workOrderManageService.findWorkOrderManageListPage(pageable,conditionName,conditionValue);
		}else{
			//查询所有数据，分页
			pageResponse= workOrderManageService.findWorkOrderManageListPage(pageable);
		}
		
		//重新组装数据
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("total", pageResponse.getTotalElements());
		resultMap.put("rows", pageResponse.getContent());
		
		//压栈顶
		ActionContext.getContext().getValueStack().push(resultMap);
		return JSON;
		
	}
	
	//值栈的拦截器封装
	private String conditionName;
	private String conditionValue;
	public void setConditionName(String conditionName) {
		this.conditionName = conditionName;
	}
	public void setConditionValue(String conditionValue) {
		this.conditionValue = conditionValue;
	}
	

}
