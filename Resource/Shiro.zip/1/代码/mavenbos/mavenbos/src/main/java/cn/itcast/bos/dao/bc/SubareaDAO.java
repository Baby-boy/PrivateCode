package cn.itcast.bos.dao.bc;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import cn.itcast.bos.domain.bc.Region;
import cn.itcast.bos.domain.bc.Subarea;

//分区dao
public interface SubareaDAO extends JpaRepository<Subarea, String>,JpaSpecificationExecutor<Subarea>{

	//没有定区的分区
	public List<Subarea> findByDecidedZoneIsNull();
	
	//根据区域查询分区列表
	public List<Subarea> findByRegion(Region region);
}
