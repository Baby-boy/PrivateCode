package cn.itcast.bos.domain.user;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

import cn.itcast.bos.domain.auth.Role;

//实体类PO类领域
@Entity
@Table(name="t_user",schema="bos34")
//命名查询
@NamedQueries({@NamedQuery(name="User.findPasswordByUsername",query="select password from User where username =?")})//hql
//@NamedNativeQueries({@NamedNativeQuery(name="",query="select * from t_user where username =?")})//sql
public class User {
	@Override
	public String toString() {
		return "User [id=" + id + ", username=" + username + ", password=" + password + ", salary=" + salary + ", birthday=" + birthday + ", gender=" + gender + ", station=" + station + ", telephone=" + telephone + ", remark=" + remark
				+ "]";
	}
	@Id
	@GeneratedValue(generator="uuidGenerator")
	@GenericGenerator(name="uuidGenerator" ,strategy="uuid")
	@Column(length=32)
	private String id;// OID
	@Column(length=20,name="username",nullable=false)
	private String username;
	@Column(length=32,nullable=false)
	private String password;
	private Double salary;
	//jpa的日期的注解
	@Temporal(TemporalType.DATE)
	private Date birthday;
	@Column(length=10)
	private String gender;
	@Column(length=40)
	private String station;
	@Column(length=11)
	private String telephone;
	@Column(length=255)
	private String remark;

	@ManyToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY)
    @JoinTable(name="T_AUTH_USER_ROLE", schema="BOS34", joinColumns = { 
        @JoinColumn(name="USER_ID", nullable=false, updatable=false) }, inverseJoinColumns = { 
        @JoinColumn(name="ROLE_ID", nullable=false, updatable=false) })
	private Set<Role> roles = new HashSet<Role>(0);
	
    public Set<Role> getRoles() {
        return this.roles;
    }
    
    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getStation() {
		return station;
	}
	public void setStation(String station) {
		this.station = station;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	

}
