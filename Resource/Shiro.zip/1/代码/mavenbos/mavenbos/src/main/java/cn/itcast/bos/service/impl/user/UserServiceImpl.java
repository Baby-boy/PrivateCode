package cn.itcast.bos.service.impl.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.itcast.bos.dao.user.UserDAO;
import cn.itcast.bos.domain.user.User;
import cn.itcast.bos.service.base.BaseService;
import cn.itcast.bos.service.user.UserService;
import cn.itcast.bos.utils.MD5Utils;

//用户操作的业务层实现
@Service("userService")
@Transactional
public class UserServiceImpl extends BaseService implements UserService{
	//注入dao
	@Autowired
	private UserDAO userDAO;

	@Override
	public void saveUser(User user) {
		user.setPassword(MD5Utils.md5(user.getPassword()));
		userDAO.save(user);
	}

	@Override
	public List<User> findAllUsers() {
		return userDAO.findAll();
	}

	@Override
	public User findByUsername(String username) {
		return userDAO.findByUsername(username);
	}

	@Override
	public String findPasswordByUsername(String username) {
		return userDAO.findPasswordByUsername(username);
	}

	@Override
	public User findUserByUsernameAndPassword(String username, String password) {
		return userDAO.findUserByUsernameAndPassword(username, password);
	}

	@Override
	public User login(User user) {
		return userDAO.findByUsernameAndPassword(user.getUsername(), MD5Utils.md5(user.getPassword()));
	}

	@Override
	public void updatePasswordForUser(User user) {
		//调用dao
		//save：具有update，修改的全部字段，这里不能用
		//更新部分字段（效率更高）
		userDAO.updatePasswordById(user.getId(), MD5Utils.md5(user.getPassword()));
		
	}

}
