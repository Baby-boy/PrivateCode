package cn.itcast.bos.dao.qp;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import cn.itcast.bos.domain.qp.WorkOrderManage;

//工作单dao
public interface WorkOrderManageDAO extends JpaRepository<WorkOrderManage, String>{
	/**
	 * 
	 * 说明：通过lucence进行分页查询数据
	 * @param pageable
	 * @param conditionName
	 * @param conditionValue
	 * @return
	 * @author 传智.BoBo老师
	 * @time：2016年10月16日 下午4:52:22
	 */
	public Page<WorkOrderManage> findListPageByLucence(Pageable pageable, String conditionName, String conditionValue);

}
