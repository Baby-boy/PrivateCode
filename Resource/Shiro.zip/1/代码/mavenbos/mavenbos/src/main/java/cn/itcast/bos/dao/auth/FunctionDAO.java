package cn.itcast.bos.dao.auth;

import org.springframework.data.jpa.repository.JpaRepository;

import cn.itcast.bos.domain.auth.Function;

//功能权限dao
public interface FunctionDAO extends JpaRepository<Function, String>{

}
