package cn.itcast.bos.dao.bc;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import cn.itcast.bos.domain.bc.Region;

//区域dao层
public interface RegionDAO extends JpaRepository<Region, String>{
	
	//根据省市区模糊匹配区域
	//1。属性表达式方式
//	public List<Region> findByProvinceLikeOrCityLikeOrDistrictLike(String province,String city,String district);
	public List<Region> findByProvinceLikeOrCityLikeOrDistrictLikeOrShortcodeOrCitycode(String province,String city,String district,String shortcode,String citycode);

	//2.query语句hql
	@Query("from Region where province like %?1% or city like %?1% or district like %?1% or shortcode =?2 or citycode =?2")
	public List<Region> findByProvinceLikeOrCityLikeOrDistrictLikeOrShortcodeOrCitycode(String param,String param2);
	
	//根据省市区精确匹配区域
	public Region findByProvinceAndCityAndDistrict(String province,String city,String district);
}
