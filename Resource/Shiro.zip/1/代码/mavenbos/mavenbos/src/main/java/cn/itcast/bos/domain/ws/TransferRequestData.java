package cn.itcast.bos.domain.ws;

import java.util.Map;

import com.google.gson.annotations.Expose;

//Webservice的传输请求数据
public class TransferRequestData {
	//接受请求的数据
	@Expose
	private String opertype;//参数类型
	@Expose
	private Map<String, String> param;//参数值
	public String getOpertype() {
		return opertype;
	}
	public void setOpertype(String opertype) {
		this.opertype = opertype;
	}
	public Map<String, String> getParam() {
		return param;
	}
	public void setParam(Map<String, String> param) {
		this.param = param;
	}
	
	//getter和setter略
	

}
