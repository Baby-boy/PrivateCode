package cn.itcast.bos.web.action.base;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

//action的父类
public abstract class BaseAction<T> extends ActionSupport implements ModelDriven<T> {
	
	//数据模型对象
	protected T model;

	@Override
	public T getModel() {
		return model;
	}
	
	//默认构造器初始化T
	public BaseAction() {
		//获取父类型
//		Type type = this.getClass().getGenericSuperclass();
//		//强转为参数化类型
//		ParameterizedType parameterizedType=( ParameterizedType)type;
//		//获取参数类型
//		Class<T> modelClass=(Class<T>) parameterizedType.getActualTypeArguments()[0];
		//...目标：向上查找父类的类型，找到参数化类型，获取泛型参数类型
		//获取到当前的class
		Class actionClass = this.getClass();
		while (true) {
			//获取父类类型
			Type superclass = actionClass.getGenericSuperclass();
			//如果找到，说明参数化类型，BaseAction<>
			if(superclass instanceof ParameterizedType){
				ParameterizedType parameterizedType=( ParameterizedType)superclass;
				//获取参数类型
				Class<T> modelClass=(Class<T>) parameterizedType.getActualTypeArguments()[0];
				//实例化
				try {
					model=modelClass.newInstance();
				} catch (InstantiationException | IllegalAccessException e) {
					e.printStackTrace();
				}
				break;
			}
			//没找到
			actionClass=(Class)superclass;
		}
		
	}
	
	//抽取工具方法
	//将对象放入session
	protected void setObjectToSession(String key,Object value){
		ServletActionContext.getRequest().getSession().setAttribute(key, value);
	}
	
	//获取参数的值
	protected String getFromParameter(String key){
		return ServletActionContext.getRequest().getParameter(key);
	}
	//从session中获取对象
	protected Object getFromSession(String key){
		return ServletActionContext.getRequest().getSession().getAttribute(key);
	}
	
	//定义常量
	public static final String JSON="json";//json类型常量
	
	//分页参数封装
	//使用属性驱动来封装参数（分页的两个）
	protected int page;//页码
	protected int rows;//每页最大记录数
	public void setPage(int page) {
		this.page = page;
	}
	public void setRows(int rows) {
		this.rows = rows;
	}

}
