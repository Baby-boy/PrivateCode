@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.itcast.cn/")
package cn.itcast.bos.dao.ws.stub;
