package cn.itcast.bos.service.impl.qp;

import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.gson.reflect.TypeToken;

import cn.itcast.bos.dao.bc.DecidedZoneDAO;
import cn.itcast.bos.dao.bc.RegionDAO;
import cn.itcast.bos.dao.bc.SubareaDAO;
import cn.itcast.bos.dao.qp.NoticeBillDAO;
import cn.itcast.bos.dao.qp.WorkBillDAO;
import cn.itcast.bos.dao.ws.stub.CustomerService;
import cn.itcast.bos.domain.bc.DecidedZone;
import cn.itcast.bos.domain.bc.Region;
import cn.itcast.bos.domain.bc.Staff;
import cn.itcast.bos.domain.bc.Subarea;
import cn.itcast.bos.domain.qp.NoticeBill;
import cn.itcast.bos.domain.qp.WorkBill;
import cn.itcast.bos.domain.ws.Customer;
import cn.itcast.bos.domain.ws.TransferRequestData;
import cn.itcast.bos.domain.ws.TransferResponseData;
import cn.itcast.bos.service.base.BaseService;
import cn.itcast.bos.service.qp.NoticeBillService;
import cn.itcast.bos.utils.GsonUtils;

//通知单的业务层实现
@Service("noticeBillService")
@Transactional
public class NoticeBillServiceImpl extends BaseService implements NoticeBillService{
	//dao层注入
	@Autowired
	private NoticeBillDAO noticeBillDAO;
	//注入ws的桩对象
	@Autowired
	private CustomerService customerService;
	
	//注入定区dao
	@Autowired
	private DecidedZoneDAO decidedZoneDAO;
	
	//注入工单的dao
	@Autowired
	private WorkBillDAO workBillDAO;
	
	//注入区域dao
	@Autowired
	private RegionDAO regionDAO;
	
	//注入分区的dao
	@Autowired
	private SubareaDAO subareaDAO;

	@Override
	public void saveNoticeBill(NoticeBill noticeBill) {
		//保存通知单
		noticeBillDAO.save(noticeBill);
		//默认就是人工调度
		noticeBill.setOrdertype("人工");//分单类型,默认人工
		//获取用户下单的地址
		String address = noticeBill.getPickaddress();
		
		//====================1.客户（发件人）地址的完全匹配。（该地址曾经下过单）
		//调用远程的ws接口
		//参数：	{'opertype':'103','param':{'address':'上海市闵行区联航路10号'}} 
		//返回值：	{'status':1,'data':[{"decidedZoneId":"DQ001"}]}
		
		//先封装参数
		TransferRequestData transferRequestData =new TransferRequestData();
		transferRequestData.setOpertype("103");
		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("address", address);
		transferRequestData.setParam(paramMap);
		
		//序列化为json
		String param = GsonUtils.toJson(transferRequestData);
		
		//调用WebService
		String result = customerService.operateCustomer(param);
		
		//解析json
		Type typeOfT = new TypeToken<TransferResponseData<Customer>>(){}.getType();
		TransferResponseData<Customer> transferResponseData= GsonUtils.fromJson(result, typeOfT);
		
		//获取结果
		if(transferResponseData.getStatus().equals("1")){
			List<Customer> customerList = transferResponseData.getData();
			
			if(customerList!=null&&!customerList.isEmpty()){
				Customer customer = customerList.get(0);
				if(StringUtils.isNotBlank(customer.getDecidedZoneId())){
					//根据定区id查询定区对象
					DecidedZone decidedZone = decidedZoneDAO.findOne(customer.getDecidedZoneId());
					if(null!=decidedZone){
						//有定区，肯定有人
						Staff staff = decidedZone.getStaff();
						//完善通知单的内容
						noticeBill.setStaff(staff);
						noticeBill.setOrdertype("自动");
						
						saveWorkBill(noticeBill, staff);
						
						//返回
						return;
					}
					
				}
			}
		}
		
		
		//=====2客户地址中的关键字匹配。
		//逻辑：根据地址找区域---》区域下面的所有分区----》根据分区的关键字找到符合的一个分区---》一个分区对应一个定区---定区就有取派员
		//地址：北京市北京市朝阳区幸福大道200号
		//获取省市区的索引
		//省
		int provinceIndex = address.indexOf("省");//2
		if(provinceIndex==-1){
			//直辖市
			provinceIndex=address.indexOf("市");
		}
		
		int cityIndex = address.indexOf("市",provinceIndex+1);
		int districtIndex = address.indexOf("区",cityIndex+1);
		//获取省市区信息
		//省：山东省
		String province=address.substring(0, provinceIndex+1);
		//市:济南市
		String city =address.substring(provinceIndex+1, cityIndex+1);
		//区
		String district =address.substring(cityIndex+1, districtIndex+1);
		
		//根据用户地址找区域（查询数据库）
		Region region = regionDAO.findByProvinceAndCityAndDistrict(province,city,district);
		//找到某区域
		if(null!=region){
			//找到区域下面的所有分区
			List<Subarea> subareaList = subareaDAO.findByRegion(region);
			//找到符合地址中包含关键字的分区
			for (Subarea subarea : subareaList) {
				if(address.contains(subarea.getAddresskey())){
					//找到了需要的分区,获取定区
					DecidedZone decidedZone = subarea.getDecidedZone();//导航查询
					if(null!=decidedZone){
						//有定区，肯定有人
						Staff staff = decidedZone.getStaff();
						//完善通知单的内容
						noticeBill.setStaff(staff);
						noticeBill.setOrdertype("自动");
						
						saveWorkBill(noticeBill, staff);
						
						//返回
						return;
						
					}
					break;
				}
			}
			
		}
		
		
		
		
	}

	/**
	 * 
	 * 说明：派单
	 * @param noticeBill
	 * @param staff
	 * @author 传智.BoBo老师
	 * @time：2016年10月16日 上午9:55:19
	 */
	private void saveWorkBill(NoticeBill noticeBill, Staff staff) {
		//派单（向工单表中插入一条数据）
		//瞬时态工单
		WorkBill workBill = new WorkBill();
		workBill.setNoticeBill(noticeBill);//通知单外键
		workBill.setType("新");//工单类型
		workBill.setPickstate("新单");//取件状态
		workBill.setBuildtime(new Date());//工单生成时间
		workBill.setAttachbilltimes(new BigDecimal(0));//追单次数
		workBill.setStaff(staff);//取派员编号
		workBill.setRemark(noticeBill.getRemark());//备注（冗余设计）
		//保存
		workBillDAO.save(workBill);
		//下发一条短信..略。。。。
	}

}
