package cn.itcast.bos.domain.ws;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Since;
//dto
public class Customer {
	//jpa，如果主键策略是auto,根据属性的数据类型进行主键值的生成
	//如果oid的属性数字类型(Integer、Long等）,策略：自增长（自动创建一个序列，并且会自动使用序列的值）
	//如果oid的属性是字符串（String）,策略：手动主键
	@Expose
	private Integer id;//OID属性
	@Expose
	private String name;//客户名称
	@Expose
	@SerializedName(value="address")//更改序列化后的key的名字，或者反序列化时对应的key的名字
	private String residence;//住所
//	@Expose(serialize=true,deserialize=false)
	@Expose
	private String telephone;//联系电话
	@Expose
//	@Since(1.0)//该字段是从1.0的版本开始有的
	private String decidedZoneId;//定区编号（客户和定区关联的字段）
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getResidence() {
		return residence;
	}
	public void setResidence(String residence) {
		this.residence = residence;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getDecidedZoneId() {
		return decidedZoneId;
	}
	public void setDecidedZoneId(String decidedZoneId) {
		this.decidedZoneId = decidedZoneId;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", residence=" + residence + ", telephone=" + telephone + ", decidedZoneId=" + decidedZoneId + "]";
	}
	
	


}
