package cn.itcast.bos.dao.bc;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import cn.itcast.bos.domain.bc.Staff;

//取派员的dao接口
public interface StaffDAO extends JpaRepository<Staff, String>{

	/**
	 * 
	 * 说明：根据id更新取派员的删除状态
	 * @param id
	 * @author 传智.BoBo老师
	 * @time：2016年10月10日 下午4:56:34
	 */
	@Query("update Staff set deltag=? where id =?")
	@Modifying
	public void updateDeltagById(Character deltag,String id);
	
	
	//根据删除状态查询员工列表
	public List<Staff> findByDeltag(Character deltag);

}
