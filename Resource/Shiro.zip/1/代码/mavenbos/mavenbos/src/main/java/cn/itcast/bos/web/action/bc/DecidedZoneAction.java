package cn.itcast.bos.web.action.bc;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Controller;

import com.opensymphony.xwork2.ActionContext;

import cn.itcast.bos.domain.bc.DecidedZone;
import cn.itcast.bos.domain.bc.Staff;
import cn.itcast.bos.domain.bc.Subarea;
import cn.itcast.bos.domain.ws.Customer;
import cn.itcast.bos.service.bc.DecidedZoneService;
import cn.itcast.bos.web.action.base.BaseAction;

//定区的action
@Controller("decidedZoneAction")
@Scope("prototype")
@ParentPackage("basic-bos")
@Namespace("/")
public class DecidedZoneAction extends BaseAction<DecidedZone>{
	//注入service
	@Autowired
	private DecidedZoneService decidedZoneService;
	
	//保存定区
	@Action(value="decidedZone_save",results={@Result(name=SUCCESS,location="/WEB-INF/pages/base/decidedzone.jsp")})
	public String save(){
		//调用业务层（封装好的数据传递过去）
		decidedZoneService.saveDecideZone(model,subareaId);
		
		return SUCCESS;
		
	}
	
	//属性驱动:封装区域id
	private String[] subareaId;
	public void setSubareaId(String[] subareaId) {
		this.subareaId = subareaId;
	}
	
	//组合条件分页列表查询
	@Action("decidedZone_listPage")
	public String listPage(){
		//1.创建两个对象，分页bean，业务条件bean
		//1)请求的分页对象
		Pageable pageable = new PageRequest(page-1, rows);
		//2)规范条件对象
		Specification<DecidedZone> spec =new Specification<DecidedZone>() {
			@Override
			public Predicate toPredicate(Root<DecidedZone> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				
				//构建集合，在最后统一拼接条件组合
				Predicate andPredicate = cb.conjunction();//相当于and的条件对象（集合在里面）
				Predicate orPredicate = cb.disjunction();//相当于or,一会放进去的自动都是or关系
				
				//定区编码
				if(StringUtils.isNotBlank(model.getId())){
					//条件1
					Predicate p1 = cb.equal(root.get("id"), model.getId());
					//添加到and条件中
					andPredicate.getExpressions().add(p1);
				}
				
				//关联取派员对象
				if(model.getStaff()!=null){
					Join<DecidedZone, Staff> staffJoin = root.join(root.getModel().getSingularAttribute("staff",Staff.class), JoinType.LEFT);
					//判断所属单位
					if(StringUtils.isNotBlank(model.getStaff().getStation())){
						andPredicate.getExpressions().add
						(cb.like(staffJoin.get("station").as(String.class), "%"+model.getStaff().getStation()+"%"));
					}
				}
				
				//是否有分区
				if(StringUtils.isNotBlank(hasSubarea)){
					//两套方案，
					//方案1：可以连接另外一个对象（这里不合适）
					//方案2：可以无需连接另外一个对象（单对象的操作）
					if(hasSubarea.equals("0")){
						//如果，你判断一个属性字段是否为空，null来判断
//						cb.isNull(root.get("subareas"));
						//如果对于集合的判断使用empty
						andPredicate.getExpressions().add(cb.isEmpty(root.get("subareas").as(Set.class)));
					}else{
						andPredicate.getExpressions().add(cb.isNotEmpty(root.get("subareas").as(Set.class)));
					}
					
				}
				
				//在这里堆积木了。。。。
//				cb.and(restrictions)
				
				return andPredicate;
			}
		};
		
		//2.调用业务层查询
		Page<DecidedZone> pageResponse= decidedZoneService.findDecidedZoneListPage(spec,pageable);
		
		
		//3.重新组装数据，压入值栈
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("total", pageResponse.getTotalElements());
		resultMap.put("rows", pageResponse.getContent());
		ActionContext.getContext().getValueStack().push(resultMap);
		
		//4.返回到json类型结果集		
		return JSON;
	}
	
	//属性驱动封装是否有分区
	private String hasSubarea;
	public void setHasSubarea(String hasSubarea) {
		this.hasSubarea = hasSubarea;
	}
	
	//没有定区的客户列表
	@Action("decidedZone_listCustomerNoDecidedZone")
	public String listCustomerNoDecidedZone(){
		//调用业务层
		List<Customer> customerList = decidedZoneService.findCustomerListNoDecidedZone();
		//压入栈顶
		ActionContext.getContext().getValueStack().push(customerList);
		
		return JSON;
	}
	//有定区的客户列表
	@Action("decidedZone_listCustomerHasDecidedZone")
	public String listCustomerHasDecidedZone(){
		//调用业务层
		List<Customer> customerList = decidedZoneService.findCustomerListHasDecidedZone(model.getId());
		//压入栈顶
		ActionContext.getContext().getValueStack().push(customerList);
		
		return JSON;
	}
	//关联客户和定区
	@Action(value="decidedZone_assigncustomerstodecidedzone",results={@Result(name=SUCCESS,location="/WEB-INF/pages/base/decidedzone.jsp")})
	public String assigncustomerstodecidedzone(){
		//重新组装客户编号
		String cIds=StringUtils.join(customerIds, ",");
		
		decidedZoneService.updateCustomerByDecidedZoneId(model.getId(), cIds);
		
		return SUCCESS;
		
	}
	
	//属性驱动封装获取要关联的客户编号
	private String[] customerIds;
	public void setCustomerIds(String[] customerIds) {
		this.customerIds = customerIds;
	}
	

	
	

}
