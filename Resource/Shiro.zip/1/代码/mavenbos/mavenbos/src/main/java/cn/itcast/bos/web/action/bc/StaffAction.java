package cn.itcast.bos.web.action.bc;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;

import com.opensymphony.xwork2.ActionContext;

import cn.itcast.bos.domain.bc.Staff;
import cn.itcast.bos.service.bc.StaffService;
import cn.itcast.bos.web.action.base.BaseAction;

//取派员的action
@Controller("satffAction")
@Scope("prototype")
@ParentPackage("basic-bos")
@Namespace("/")
public class StaffAction extends BaseAction<Staff> {
	//注入业务层
	@Autowired
	private StaffService staffService;
	
	//保存取派员
	@Action(value="staff_save",results={@Result(name=SUCCESS,location="/WEB-INF/pages/base/staff.jsp")})
	public String save(){
		//调用业务层
		staffService.saveStaff(model);
		//跳转到datagrid（自己加载列表）页面跳
		return SUCCESS;
	}
	
	
	//分页列表查询
	@Action("staff_listPage")
	public String listPage(){
		//先获取两个参数：当前页码page，每页最大记录数rows
		//可以通过原始servlet：getparampa（）；。。。。
		//也可以通过属性驱动获取（这里使用）
		
		//调用业务层查询了。。。。。。
		//到底怎么写业务层：要看你的持久层方案了。
		//1传统方案：拼接sql、Criteria，查询两次，一次是总记录数，一次，当页的记录列表
		//2.spring data jpa:提供了分页的方案，一个api就搞定！
		
		//选择方案2
		//先构建一个Pageable pageable对象
		//参数1：当页的页码的‘’索引‘’！！！ ，Pages are zero indexed,
		//参数2：每页最大记录数
		Pageable pageable=new PageRequest(page-1, rows);
		Page<Staff>  pageResponse=staffService.findStaffListPage(pageable);
		
		//结果，封装为指定格式的json，给response
		//对象压入栈顶即可，使用json插件转换。。
//		ActionContext.getContext().getValueStack().push(pageResponse);
		
		//重新组装数据
		Map<String, Object> resultMap = new HashMap<String, Object>();
		//总记录数
		resultMap.put("total", pageResponse.getTotalElements());
		//当前页的记录列表
		resultMap.put("rows", pageResponse.getContent());
		
		//将map压入栈顶
		ActionContext.getContext().getValueStack().push(resultMap);
		
		//json类型的结果集类型
		return JSON;
		
	}
	
	//使用属性驱动来封装参数（分页的两个）
	private int page;//页码
	private int rows;//每页最大记录数
	public void setPage(int page) {
		this.page = page;
	}
	public void setRows(int rows) {
		this.rows = rows;
	}
	
	//作废取派员
	@Action("staff_deleteBatch")
	public String deleteBatch(){
		//获取ids，将其传递给业务层
		//这次采用原始取参数的方式
		String ids=super.getFromParameter("ids");
		
		
		//返回结果给客户看
		Map<String, Object> resultMap = new HashMap<>();
		
		//给业务层
		try {
			staffService.deleteStaffBatch(ids);
			resultMap.put("result", true);
		} catch (Exception e) {
			e.printStackTrace();
			resultMap.put("result", false);
		}
		
		//压入栈顶
		ActionContext.getContext().getValueStack().push(resultMap);
		
		return JSON;
	}
	
	//获取正常的取派员信息
	@Action("staff_listNoDeltag")
	public String listNoDeltag(){
		//调用业务层查询
		List<Staff> staffList= staffService.findStaffListNoDeltag();
		//将数据压入栈顶
		ActionContext.getContext().getValueStack().push(staffList);
		
		return JSON;
	}
	
	

}
