package cn.itcast.bos.web.interceptor;

import org.apache.struts2.ServletActionContext;
import org.springframework.stereotype.Component;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.MethodFilterInterceptor;

//登录拦截器
@Component("loginInterceptor")//单例
public class LoginInterceptor extends MethodFilterInterceptor{

	@Override
	protected String doIntercept(ActionInvocation invocation) throws Exception {
		
		//判断session是否有用户对象
		if(null==ServletActionContext.getRequest().getSession().getAttribute("loginUser")){
			//没有登录
			
			//跳转到登录页面
//			return "login";
			return Action.LOGIN;//常量
		}
		
		//放行
		return invocation.invoke();
	}

}
