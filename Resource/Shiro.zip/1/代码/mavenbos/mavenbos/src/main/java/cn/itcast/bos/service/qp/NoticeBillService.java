package cn.itcast.bos.service.qp;

import cn.itcast.bos.domain.qp.NoticeBill;

//通知单的业务层接口
public interface NoticeBillService {

	/**
	 * 
	 * 说明：通知单的新单（保存通知单和自动派单）
	 * @param noticeBill
	 * @author 传智.BoBo老师
	 * @time：2016年10月14日 下午5:02:34
	 */
	public void saveNoticeBill(NoticeBill noticeBill);

}
