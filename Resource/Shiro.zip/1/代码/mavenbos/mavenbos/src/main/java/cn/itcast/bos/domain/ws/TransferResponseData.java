package cn.itcast.bos.domain.ws;

import java.util.List;

import com.google.gson.annotations.Expose;

//Webservice的传输响应数据
public class TransferResponseData<T> {
	
	//返回响应的数据
	@Expose
	private String status;//返回状态
	@Expose
	private List<T> data;//返回数据
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public List<T> getData() {
		return data;
	}
	public void setData(List<T> data) {
		this.data = data;
	}
	
	//getter和setter略
}
