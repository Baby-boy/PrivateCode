package cn.itcast.bos.web.action.bc;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Controller;

import com.opensymphony.xwork2.ActionContext;

import cn.itcast.bos.domain.bc.Region;
import cn.itcast.bos.domain.bc.Subarea;
import cn.itcast.bos.service.bc.SubareaService;
import cn.itcast.bos.utils.FileUtils;
import cn.itcast.bos.web.action.base.BaseAction;

//分区管理
@Controller("subareaAction")
@Scope("prototype")
@ParentPackage("basic-bos")
@Namespace("/")
public class SubareaAction extends BaseAction<Subarea>{
	//注入service
	@Autowired
	private SubareaService subareaService;

	//保存数据
	@Action(value="subarea_save",results={@Result(name=SUCCESS,location="/WEB-INF/pages/base/subarea.jsp")})
	@RequiresRoles("weihu1")
	public String save(){
		//调用业务层
		subareaService.saveSubarea(model);
		
		return SUCCESS;
	}
	
	//组合条件分页查询
	@Action("subarea_listPage")
	@RequiresRoles("weihu1")//只有weihu的角色才能访问该方法
	public String listPage(){
		//业务：获取页面传递过来的条件（业务+分页），进行处理，获取数据，转换为j送，给datagrid
		
		//技术方案：
		//1.传统方式：拼接sql(Criteria)，spring练习一样
		//2.spring data jpa:使用Specification方案（存放业务条件）
		//1)分页条件bean
		Pageable pageable = new PageRequest(page-1, rows);
		//2)业务条件bean（Specification：条件规范-封装jpa的Criteria），
		Specification<Subarea> spec = getSubareaSpecification();
		Page<Subarea> pageResponse= subareaService.findSubareaListPage(spec, pageable);
		
		//重新组装数据
		Map<String,Object> resultMap = new HashMap<>();
		//总记录数
		resultMap.put("total", pageResponse.getTotalElements());
		//当前页的数据列表
		resultMap.put("rows", pageResponse.getContent());
		
		//压入栈顶
		ActionContext.getContext().getValueStack().push(resultMap);
		
		return JSON;
	}

	//获取参数条件封装对象
	private Specification<Subarea> getSubareaSpecification() {
		Specification<Subarea> spec=new Specification<Subarea>() {
			@Override
			//参数1：根查询对象（path-》Customer(root)--属性Orders）
			//参数2：简单查询对象(拼接条件)（jpa的对象）--不推荐直接使用该对象
			//参数3：构建条件对象的对象（工具对象）（jpa的对象）
			//返回：相当于where语句后面的and  or。。
			public Predicate toPredicate(Root<Subarea> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				//构建list，临时存放条件
				List<Predicate> andPredicate=new ArrayList<>();//用来装and
				List<Predicate> orPredicate=new ArrayList<>();//用来装or
				
				
				//===============单表
				//关键字
				if(StringUtils.isNotBlank(model.getAddresskey())){
					//参数1：属性（路径）
					//参数2：值
					//相当于： addresskey=?
					Predicate p1 = cb.equal(root.get("addresskey"), model.getAddresskey());
					andPredicate.add(p1);
				}
				//定区编号
				if(model.getDecidedZone()!=null&&StringUtils.isNotBlank(model.getDecidedZone().getId())){
					//1）
					Predicate p2 = cb.equal(root.get("decidedZone"), model.getDecidedZone());//外键对象
					//2)
//					cb.equal(root.get("decidedZone.id"), model.getDecidedZone().getId());
					andPredicate.add(p2);
				}
				//==============多表
				if(model.getRegion()!=null){
					//参数1：属性或path
					//参数2：关联的类型，内联，左外,如果不加该参数，则默认内联
	//				Join<Object, Object> join = root.join("region", JoinType.INNER);
	//				Join<Subarea, ?> join = root.join(root.getModel().getSingularAttribute("region"), JoinType.INNER);
					Join<Subarea, Region> regionJoin = root.join(root.getModel().getSingularAttribute("region",Region.class), JoinType.INNER);
					
					//省
					if(StringUtils.isNotBlank(model.getRegion().getProvince())){
						 Predicate p3 = cb.like(regionJoin.get("province").as(String.class), "%"+model.getRegion().getProvince()+"%");
						 andPredicate.add(p3);
					}
					
					//市
					if(StringUtils.isNotBlank(model.getRegion().getCity())){
						 Predicate p4 = cb.like(regionJoin.get("city").as(String.class), "%"+model.getRegion().getCity()+"%");
						 andPredicate.add(p4);
					}
					
					//区
					if(StringUtils.isNotBlank(model.getRegion().getDistrict())){
						 Predicate p5 = cb.like(regionJoin.get("district").as(String.class), "%"+model.getRegion().getDistrict()+"%");
						 andPredicate.add(p5);
					}
					
				}
				
				//拼接关系
//				cb.and(p1,p2,p3);//将是and的关系
//				cb.or(restrictions);//将是or的关系
				//cb可以组合为及其复杂的条件where (a and b ) or( c and d) 
				
				Predicate[] andPredicateArray = andPredicate.toArray(new Predicate[0]);
				return cb.and(andPredicateArray);
				
			}
		};
		return spec;
	}
	
	//导出分区的excel
	@Action("subarea_exportData")
	public String exportData() throws Exception{
		//三步：
		//1。查询出数据列表（带条件）
		//业务条件bean（Specification：条件规范-封装jpa的Criteria），
		Specification<Subarea> spec = getSubareaSpecification();
		List<Subarea> subareaList = subareaService.findSubareaList(spec);
		
		//2.将列表写成excel文件
		//现实写excel的步骤一样
		//1）创建一个空excel工作簿
		HSSFWorkbook hssfWorkbook = new HSSFWorkbook();
		
		//2)创建一个工作表sheet
//		hssfWorkbook.createSheet();
		HSSFSheet sheet = hssfWorkbook.createSheet("分区数据");
		
		//3）创建一行数据（头数据-第一行）
		HSSFRow headerRow = sheet.createRow(0);
		//创建格，并添加数据
		headerRow.createCell(0).setCellValue("分区编号");
		headerRow.createCell(1).setCellValue("区域编码");
		headerRow.createCell(2).setCellValue("关键字");
		headerRow.createCell(3).setCellValue("起始号");
		headerRow.createCell(4).setCellValue("结束号");
		headerRow.createCell(5).setCellValue("单双号");
		headerRow.createCell(6).setCellValue("位置信息");
		
		//4)创建其他行和数据
		for (Subarea subarea : subareaList) {
			//在最后一行的下一行创建新行
			HSSFRow row = sheet.createRow(sheet.getLastRowNum()+1);
			//创建格，并添加数据
			row.createCell(0).setCellValue(subarea.getId());
			row.createCell(1).setCellValue(subarea.getRegion().getId());
			row.createCell(2).setCellValue(subarea.getAddresskey());
			row.createCell(3).setCellValue(subarea.getStartnum());
			row.createCell(4).setCellValue(subarea.getEndnum());
			row.createCell(5).setCellValue(subarea.getSingle().toString());//Character不识别
			row.createCell(6).setCellValue(subarea.getPosition());
		}
		
		//3.将其放入响应，提供下载（两个属性）
		//获取响应对象
		HttpServletResponse response = ServletActionContext.getResponse();
		
		
		//两个属性
		//设置客户端浏览器用于识别附件的两个参数Content-Type和Content-Disposition
		//文件名
		String downFilename="分区数据.xls";
		//获取文件的MIME类型：
		String contentType=ServletActionContext.getServletContext().getMimeType(downFilename);
		//将MIME类型放入响应
		response.setContentType(contentType);
		//浏览器类型
		String agent = ServletActionContext.getRequest().getHeader("user-agent");
		//附件名编码，解决中文乱码问题
		downFilename = FileUtils.encodeDownloadFilename(downFilename, agent);
		//获取附件的名字和下载方式
		String contentDisposition="attachment;filename="+downFilename;
		//将附件名字和下载方式放入响应头信息中
		response.setHeader("Content-Disposition", contentDisposition);

		//将Excel的文件流写入到客户端响应中

		hssfWorkbook.write(response.getOutputStream());
		
		//返回
		return NONE;
		
	}
	
	//查询没有定区的分区
	@Action("subarea_listNoDecidedZone")
	public String listNoDecidedZone(){
		//调用业务层查询
		List<Subarea> subareaList= subareaService.findSubareaListNoDecidedZone();
		//压栈
		ActionContext.getContext().getValueStack().push(subareaList);
		return JSON;
	}
}
