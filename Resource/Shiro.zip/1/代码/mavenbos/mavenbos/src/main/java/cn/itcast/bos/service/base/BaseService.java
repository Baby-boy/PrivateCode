package cn.itcast.bos.service.base;
//业务层父类
public abstract class BaseService {

}
