package cn.itcast.bos.service.bc;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import cn.itcast.bos.domain.bc.Staff;

//取派员业务层接口
public interface StaffService {

	/**
	 * 
	 * 说明：保存取派员
	 * @param staff
	 * @author 传智.BoBo老师
	 * @time：2016年10月10日 上午11:53:27
	 */
	public void saveStaff(Staff staff);

	/**
	 * 
	 * 说明：分页列表查询取派员
	 * @param pageable
	 * @return
	 * @author 传智.BoBo老师
	 * @time：2016年10月10日 下午3:24:30
	 */
	public Page<Staff> findStaffListPage(Pageable pageable);

	/**
	 * 
	 * 说明：批量作废取派员
	 * @param ids
	 * @author 传智.BoBo老师
	 * @time：2016年10月10日 下午4:52:39
	 */
	public void deleteStaffBatch(String ids);

	/**
	 * 
	 * 说明：查询没有作废的取派员
	 * @return
	 * @author 传智.BoBo老师
	 * @time：2016年10月13日 上午10:38:26
	 */
	public List<Staff> findStaffListNoDeltag();

}
