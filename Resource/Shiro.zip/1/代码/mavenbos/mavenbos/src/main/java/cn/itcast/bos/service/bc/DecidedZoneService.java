package cn.itcast.bos.service.bc;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import cn.itcast.bos.domain.bc.DecidedZone;
import cn.itcast.bos.domain.ws.Customer;

//定区业务层接口
public interface DecidedZoneService {

	/**
	 * 
	 * 说明：
	 * @param decidedZone
	 * @param subareaIds
	 * @author 传智.BoBo老师
	 * @time：2016年10月13日 上午11:26:36
	 */
	public void saveDecideZone(DecidedZone decidedZone, String[] subareaIds);

	/**
	 * 
	 * 说明：组合条件分页查询
	 * @param spec
	 * @param pageable
	 * @return
	 * @author 传智.BoBo老师
	 * @time：2016年10月13日 下午3:18:37
	 */
	public Page<DecidedZone> findDecidedZoneListPage(Specification<DecidedZone> spec, Pageable pageable);
	
	
	//远程调用：
	/**
	 * 
	 * 说明：查询没有关联定区的客户
	 * @return
	 * @author 传智.BoBo老师
	 * @time：2016年10月14日 上午11:40:43
	 */
	public List<Customer> findCustomerListNoDecidedZone();
	/**
	 * 
	 * 说明：查询已经关联某定区的客户
	 * @param decidedZoneId
	 * @return
	 * @author 传智.BoBo老师
	 * @time：2016年10月14日 上午11:41:40
	 */
	public List<Customer> findCustomerListHasDecidedZone(String decidedZoneId);
	
	/**
	 * 
	 * 说明：关联定区和用户
	 * @param decidedZoneId
	 * @param customerIds
	 * @author 传智.BoBo老师
	 * @time：2016年10月14日 上午11:42:32
	 */
	public void updateCustomerByDecidedZoneId(String decidedZoneId,String customerIds);
	
	

}
