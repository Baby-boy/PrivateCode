package cn.itcast.bos.service.bc;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import cn.itcast.bos.domain.bc.Subarea;

//分区业务层接口
public interface SubareaService {

	/**
	 * 
	 * 说明：保存分区
	 * @param subarea
	 * @author 传智.BoBo老师
	 * @time：2016年10月11日 下午3:58:04
	 */
	public void saveSubarea(Subarea subarea);
	
	/**
	 * 
	 * 说明：组合条件分页查询
	 * @param spec
	 * @param pageable
	 * @return
	 * @author 传智.BoBo老师
	 * @time：2016年10月11日 下午4:57:54
	 */
	public Page<Subarea> findSubareaListPage(Specification<Subarea> spec, Pageable pageable);

	/**
	 * 
	 * 说明：业务条件查询分区列表
	 * @param spec
	 * @return
	 * @author 传智.BoBo老师
	 * @time：2016年10月13日 上午9:44:40
	 */
	public List<Subarea> findSubareaList(Specification<Subarea> spec);

	/**
	 * 
	 * 说明：查询没有定区的分区列表
	 * @return
	 * @author 传智.BoBo老师
	 * @time：2016年10月13日 上午10:53:49
	 */
	public List<Subarea> findSubareaListNoDecidedZone();

}
