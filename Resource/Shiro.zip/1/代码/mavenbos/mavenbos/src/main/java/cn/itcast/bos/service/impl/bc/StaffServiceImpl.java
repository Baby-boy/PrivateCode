package cn.itcast.bos.service.impl.bc;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.itcast.bos.dao.bc.StaffDAO;
import cn.itcast.bos.domain.bc.Staff;
import cn.itcast.bos.service.base.BaseService;
import cn.itcast.bos.service.bc.StaffService;

//取派员的业务层实现
@Service("staffService")
@Transactional
public class StaffServiceImpl extends BaseService implements StaffService {
	//注入dao
	@Autowired
	private StaffDAO staffDAO;

	@Override
	public void saveStaff(Staff staff) {
		//调用dao保存
		//如果staff中有id，则先查询数据库，看有没有数据，如果有，则更新，如果没有则保存
		//如果staff中没有id，直接保存
		staffDAO.save(staff);
		
	}

	@Override
	public Page<Staff> findStaffListPage(Pageable pageable) {
		return staffDAO.findAll(pageable);
	}

	@Override
	public void deleteStaffBatch(String ids) {
		//切割ids为数组
		String[] idArray = ids.split(",");
		for (String id : idArray) {
			//物理删除(不行)
//			staffDAO.delete(id);
			//逻辑删除
			//更新操作:deltag :0--->1
			//1。方式1：快照更新
//			Staff staff = staffDAO.findOne(id);
//			staff.setDeltag('1');
			//2.方式2：自定义语句update
			staffDAO.updateDeltagById('1',id);
			
		}
		
		
		
	}

	@Override
	public List<Staff> findStaffListNoDeltag() {
		//1.属性表达式
		return staffDAO.findByDeltag('0');
	}

}
