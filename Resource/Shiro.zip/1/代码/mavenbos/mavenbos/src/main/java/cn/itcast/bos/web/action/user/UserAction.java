package cn.itcast.bos.web.action.user;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.interceptor.annotations.InputConfig;

import cn.itcast.bos.domain.user.User;
import cn.itcast.bos.service.user.UserService;
import cn.itcast.bos.utils.MD5Utils;
import cn.itcast.bos.web.action.base.BaseAction;

//用户操作的action
@Controller("userAction")
@Scope("prototype")
//@ParentPackage("struts-default")
@ParentPackage("basic-bos")//继承为了复用
@Namespace("/")
public class UserAction extends BaseAction<User>{
	//注入业务层bean
	@Autowired
	private UserService userService;
	
	
	//登录业务
	@Action(value="user_login"
			,results={@Result(name="login",location="/login.jsp")
			,@Result(name="success",type="redirect", location="/index.jsp")})
	@InputConfig(resultName="login")
	public String login(){
		//----------验证码验证
		//获取验证码参数的值
		String checkcode = getFromParameter("checkcode");
		//获取session中验证码值
		String checkCodeSession = (String)getFromSession("key");
		//如果验证码没有输入，或者输入错误，都跳转到登录页面，给提示
		if(StringUtils.isBlank(checkcode)||!checkcode.equalsIgnoreCase(checkCodeSession)){
			//提示
			addActionError(getText("UserAction.checkcodeerror"));
			//跳转到登录
			return LOGIN;
		}
		
		
		//-----------登录验证
		//=====传统的手工认证方式
//		//调用业务层查询
//		User loginUser=userService.login(model);
//		//判断
//		if(loginUser==null){
//			//登录失败
//			addActionError(getText("UserAction.loginerror"));
//			//跳转到登录页面
//			return LOGIN;
//		}else{
//			//登录成功
//			//用户放入session
////			ServletActionContext.getRequest().getSession().setAttribute(name, value);
//			super.setObjectToSession("loginUser", loginUser);
//			//跳转到主页
//			return SUCCESS;
//		}
		//====shiro的认证方式
		//目标：使用subject对象进行登录认证操作
		//获取subject对象（“用户”对象）
		Subject subject = SecurityUtils.getSubject();
		
		//构建一个令牌token对象（用户名密码-用户输入的）
		AuthenticationToken token =new UsernamePasswordToken(model.getUsername(), MD5Utils.md5(model.getPassword()));
		
		//认证操作（门卫检查腰牌）
		try {
			subject.login(token);
			//认证通过，登录成功，跳转到主页
			return SUCCESS;
		}catch(UnknownAccountException e){
			e.printStackTrace();
			addActionError(getText("UserAction.usernotexist"));
			return LOGIN;
		}catch(IncorrectCredentialsException e){
			e.printStackTrace();
			addActionError(getText("UserAction.passwordincorrect"));
			return LOGIN;
		} catch (AuthenticationException e) {
			e.printStackTrace();
			//登录失败，认证失败，跳转到登录
			addActionError(getText("UserAction.loginerror"));
			return LOGIN;
		}
		
		
	}
	
	//退出
	@Action(value="user_logout",results={@Result(name=LOGIN,type="redirect",location="/login.jsp")})
	public String logout(){
		//======传统方式的退出
		//销毁session中用户对象
//		ServletActionContext.getRequest().getSession().removeAttribute("loginUser");
		//推荐:销毁所有用户自定义的对象
//		ServletActionContext.getRequest().getSession().invalidate();
		
		//=======shiro方式的退出
		//shiro也是将用户登录等相关信息都放入“session”了
		//不建议上面的api，原因：
		//1.shiro不一定会持久httpsession，普通的java程序没有httpsession
		//2.shiro登录之后，还在内存中持有其他的相关对象
		
		//获取“用户”对象
		SecurityUtils.getSubject().logout();//释放所有资源，并清除“session”
		
		//返回登录
		return LOGIN;
	}
	
	//修改密码(异步，返回json)
	@Action(value="user_editpassword")
//			,results={@Result(name=JSON,type=JSON)})
	public String editpassword(){
		//获取当前登录用户
		User loginUser=(User)super.getFromSession("loginUser");
		//将id，放入封装model（现在只有密码）
		model.setId(loginUser.getId());
		
		//定义一个map，存放结果
		Map<String, Object> resultMap =new HashMap<String, Object>();
		try {
			//先修改密码
			userService.updatePasswordForUser(model);
			//修改成功
			resultMap.put("result", true);
		} catch (Exception e) {
			e.printStackTrace();
			//修改失败
			resultMap.put("result", false);
		}
		
		//将是否成功结果放入栈顶{'result':true}
		ActionContext.getContext().getValueStack().push(resultMap);
		
		//返回json类型的结果集
//		return "json";
		return JSON;
		
	}

}
