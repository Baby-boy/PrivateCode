package cn.itcast.bos.service.impl.bc;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.gson.reflect.TypeToken;

import cn.itcast.bos.dao.bc.DecidedZoneDAO;
import cn.itcast.bos.dao.bc.SubareaDAO;
import cn.itcast.bos.dao.ws.stub.CustomerService;
import cn.itcast.bos.domain.bc.DecidedZone;
import cn.itcast.bos.domain.bc.Subarea;
import cn.itcast.bos.domain.ws.Customer;
import cn.itcast.bos.domain.ws.TransferRequestData;
import cn.itcast.bos.domain.ws.TransferResponseData;
import cn.itcast.bos.service.base.BaseService;
import cn.itcast.bos.service.bc.DecidedZoneService;
import cn.itcast.bos.utils.GsonUtils;

//定区管理的业务层实现
@Service("decidedZoneService")
@Transactional
public class DecidedZoneServiceImpl extends BaseService implements DecidedZoneService{
	//注入定区的dao
	@Autowired
	private DecidedZoneDAO decidedZoneDAO;
	//注入分区的dao
	@Autowired
	private SubareaDAO subareaDAO;
	
	//注入桩对象(webservice)
	@Autowired
	private CustomerService customerService;
	

	@Override
	public void saveDecideZone(DecidedZone decidedZone, String[] subareaIds) {
		//1.保存定区
		//如果是纯的jpa或hibernate操作，该动作：瞬时态转为持久态
		//这里的api是spring data jpa，还没有通知hibernate，hibernate的一级缓存没有
//		decidedZoneDAO.save(decidedZone);
		//spring data jpa的flush，会将实体对象交给hibernate了，并且也自动调用hibernate的flush
		decidedZoneDAO.saveAndFlush(decidedZone);//持久态了
		
		//2.更新分区中的定区外键关联
		//更新：快照更新互或update更新所有(save)
		//subareaDAO.save("完整实体，否则会丢失属性值")
		if(null!=subareaIds){
			for (String subareaId : subareaIds) {
				//快照。。。。。
				//先查询
				Subarea subarea = subareaDAO.findOne(subareaId);
				//更改一级缓存属性
				//object references an unsaved transient instance
				subarea.setDecidedZone(decidedZone);//外键
				//等待flush
			}
		}
		
	}


	@Override
	public Page<DecidedZone> findDecidedZoneListPage(Specification<DecidedZone> spec, Pageable pageable) {
		return decidedZoneDAO.findAll(spec, pageable);
	}


	@Override
	public List<Customer> findCustomerListNoDecidedZone() {
		//先封装参数
		TransferRequestData transferRequestData =new TransferRequestData();
		transferRequestData.setOpertype("101");
		
		//序列化为json
		String param = GsonUtils.toJson(transferRequestData);
		
		//调用WebService
		String result = customerService.operateCustomer(param);
		
		//解析json
		Type typeOfT = new TypeToken<TransferResponseData<Customer>>(){}.getType();
		TransferResponseData<Customer> transferResponseData= GsonUtils.fromJson(result, typeOfT);
		
		//获取结果
		if(transferResponseData.getStatus().equals("1")){
			return transferResponseData.getData();
		}
		
		return null;
	}


	@Override
	public List<Customer> findCustomerListHasDecidedZone(String decidedZoneId) {
		//先封装参数
		TransferRequestData transferRequestData =new TransferRequestData();
		transferRequestData.setOpertype("102");
		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("decidedZoneId", decidedZoneId);
		transferRequestData.setParam(paramMap);
		
		//序列化为json
		String param = GsonUtils.toJson(transferRequestData);
		
		//调用WebService
		String result = customerService.operateCustomer(param);
		
		//解析json
		Type typeOfT = new TypeToken<TransferResponseData<Customer>>(){}.getType();
		TransferResponseData<Customer> transferResponseData= GsonUtils.fromJson(result, typeOfT);
		
		//获取结果
		if(transferResponseData.getStatus().equals("1")){
			return transferResponseData.getData();
		}
		
		return null;
	}


	@Override
	public void updateCustomerByDecidedZoneId(String decidedZoneId, String customerIds) {
		//先封装参数
		TransferRequestData transferRequestData =new TransferRequestData();
		transferRequestData.setOpertype("201");
		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("decidedZoneId", decidedZoneId);
		paramMap.put("customerIds", customerIds);
		transferRequestData.setParam(paramMap);
		//序列化为json
		String param = GsonUtils.toJson(transferRequestData);
		
		//调用WebService
		String result = customerService.operateCustomer(param);
		
		//解析json
		Type typeOfT = new TypeToken<TransferResponseData<Customer>>(){}.getType();
		TransferResponseData<Customer> transferResponseData= GsonUtils.fromJson(result, typeOfT);
		
		//获取结果
		if(!transferResponseData.getStatus().equals("1")){
			throw new RuntimeException("接口调用服务端异常：根据定区编号更新客户失败！");
		}
		
	}

}
