package cn.itcast.bos.web.action.qp;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import cn.itcast.bos.domain.qp.NoticeBill;
import cn.itcast.bos.domain.user.User;
import cn.itcast.bos.service.qp.NoticeBillService;
import cn.itcast.bos.web.action.base.BaseAction;

//通知单的action
@Controller("noticeBillAction")
@Scope("prototype")
@ParentPackage("basic-bos")
@Namespace("/")
public class NoticeBillAction extends BaseAction<NoticeBill>{
	//注入service
	@Autowired
	private NoticeBillService noticeBillService;
	
	//新单（保存通知单+自动下单）
	@Action(value="noticeBill_save",results={@Result(name=SUCCESS,location="/WEB-INF/pages/qupai/noticebill_add.jsp")})
	public String save(){
		//获取当前登陆人
		User loginUser = (User) super.getFromSession("loginUser");
		//塞到model
		model.setUser(loginUser);
		//保存
		noticeBillService.saveNoticeBill(model);
		
		return SUCCESS;
	}

}
