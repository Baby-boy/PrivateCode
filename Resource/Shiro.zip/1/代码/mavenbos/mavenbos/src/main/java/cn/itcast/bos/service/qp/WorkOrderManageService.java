package cn.itcast.bos.service.qp;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import cn.itcast.bos.domain.qp.WorkOrderManage;

//工作单管理的业务接口
public interface WorkOrderManageService {

	/**
	 * 
	 * 说明：保存工作单
	 * @param workOrderManage
	 * @author 传智.BoBo老师
	 * @time：2016年10月16日 上午11:31:55
	 */
	public void saveWorkOrderManage(WorkOrderManage workOrderManage);

	/**
	 * 
	 * 说明：f分页查询所有数据列表
	 * @param pageable
	 * @return
	 * @author 传智.BoBo老师
	 * @time：2016年10月16日 下午2:42:08
	 */
	public Page<WorkOrderManage> findWorkOrderManageListPage(Pageable pageable);

	/**
	 * 
	 * 说明：全文检索的方式是查询数据列表
	 * @param pageable
	 * @param conditionName
	 * @param conditionValue
	 * @return
	 * @author 传智.BoBo老师
	 * @time：2016年10月16日 下午4:49:58
	 */
	public Page<WorkOrderManage> findWorkOrderManageListPage(Pageable pageable, String conditionName, String conditionValue);

}
