package cn.itcast.bos.dao.impl.qp;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.lucene.index.Term;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.BooleanClause.Occur;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.WildcardQuery;
import org.apache.lucene.util.Version;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.wltea.analyzer.lucene.IKAnalyzer;

import cn.itcast.bos.domain.qp.WorkOrderManage;

//工作单的dao实现类
//dao实现类的要求：
//1.必须<jpa:repositories base-package="cn.itcast.bos.dao"/>能扫描到
//2.必须类名是接口的名字+Impl后缀才行
//无需实现dao的接口
public class WorkOrderManageDAOImpl{
	
	//注入实体管理对象（jpa的）
	@PersistenceContext
	private EntityManager entityManager;//相当于hibernate的session

	//通过lucence全文检索的方式来查询工作单分页列表对象
	public Page<WorkOrderManage> findListPageByLucence(Pageable pageable, String conditionName, String conditionValue){
		//1.构建查询搜索对象query（org.apache.lucene.search.Query）
		//lucence的Query对象
//		Query query =null;
		//=====规则1：一类长词分词模糊匹配（黑马程序员）
		//先分词，因此先构建一个查询分词器，专门用来分查询的关键字的词
		//参数1：luncene的版本号，固定
		//参数2：分词的字段
		//参数3：分词器
		QueryParser queryParser = new QueryParser(Version.LUCENE_31, conditionName, new IKAnalyzer());
		
		//获取分词后的Query
		Query changciQuery=null;
		try {
			changciQuery = queryParser.parse(conditionValue);
		} catch (ParseException e) {
			e.printStackTrace();
			throw new RuntimeException("QueryParser分词失败。。。");
		}
		
		//=====规则2：短词直接匹配(模糊)
		//参数：term：词条(参数1：字段，参数2：查询的内容关键字)
		Query duanciQuery=new WildcardQuery(new Term(conditionName, "*"+conditionValue+"*"));
		
		//将多个规则结合起来
		BooleanQuery query=new BooleanQuery();
		//参数1：query对象
		//参数2：逻辑关系，and 或or等
//		query.add(changciQuery, Occur.MUST);//相当于and的关系，该查询规则必须有
		query.add(changciQuery, Occur.SHOULD);//相当于or的关系，该查询规则必须有
		query.add(duanciQuery, Occur.SHOULD);
		
		//2.调用hibernateSearch的api，检索数据（先查索引库，再根据id查询数据库，自动封装对象）
		//根据EntityManager来创建一个全文实体管理对象
		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);
		//创建一个全文检索的查询对象（用来检索对象用的）
		//参数1：Query对象（org.apache.lucene.search.Query）
		//参数2：检索的对象的类型（自动将结果封装到该类型）
		FullTextQuery fullTextQuery = fullTextEntityManager.createFullTextQuery(query, WorkOrderManage.class);
		
		//设置一条检索的条件
		fullTextQuery.setFirstResult(pageable.getPageNumber()*pageable.getPageSize());
		fullTextQuery.setMaxResults(pageable.getPageSize());

		List resultList = fullTextQuery.getResultList();//相当于查询索引库，又查询数据库，又封装数据
		
		//3.组装数据
		//总记录数
		int total = fullTextQuery.getMaxResults();
		Page<WorkOrderManage> pageResponse =new PageImpl<>(resultList, pageable, total);
		
		return pageResponse;
	}
}
