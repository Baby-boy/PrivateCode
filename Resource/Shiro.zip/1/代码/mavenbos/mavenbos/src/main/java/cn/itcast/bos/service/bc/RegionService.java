package cn.itcast.bos.service.bc;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import cn.itcast.bos.domain.bc.Region;

//区域的业务层接口
public interface RegionService {

	/**
	 * 
	 * 说明：批量保存区域
	 * @param regionList
	 * @author 传智.BoBo老师
	 * @time：2016年10月11日 上午11:14:09
	 */
	public void saveRegion(List<Region> regionList);

	/**
	 * 
	 * 说明：分页查询列表
	 * @param pageable
	 * @return
	 * @author 传智.BoBo老师
	 * @time：2016年10月11日 下午2:39:05
	 */
	public Page<Region> findRegionListPage(Pageable pageable);

	/**
	 * 
	 * 说明：查询所有的区域
	 * @return
	 * @author 传智.BoBo老师
	 * @param param 
	 * @time：2016年10月11日 下午2:54:50
	 */
	public List<Region> findRegionList();
	
	/**
	 * 
	 * 说明：根据参数查询列表
	 * @param param
	 * @return
	 * @author 传智.BoBo老师
	 * @time：2016年10月11日 下午3:08:28
	 */
	public List<Region> findRegionList(String param);

}
