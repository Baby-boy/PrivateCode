package cn.itcast.bos.web.action.bc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;

import com.opensymphony.xwork2.ActionContext;

import cn.itcast.bos.domain.bc.Region;
import cn.itcast.bos.service.bc.RegionService;
import cn.itcast.bos.utils.PinYin4jUtils;
import cn.itcast.bos.web.action.base.BaseAction;

//区域的action
@Controller("regionAction")
@Scope("prototype")
@ParentPackage("basic-bos")
@Namespace("/")
public class RegionAction extends BaseAction<Region>{
	
	//注入service
	@Autowired
	private RegionService regionService;
	
	//通过struts2的fileupdateinter..拦截器，自动处理上传的文件
	private File upload;//file的name
	private String uploadFileName;//文件名，可以通过扩展名用来判断文件类型
	private String uploadContentType;//文件类型，可以通过mime类型来判断文件类型
	public void setUpload(File upload) {
		this.upload = upload;
	}
	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}
	public void setUploadContentType(String uploadContentType) {
		this.uploadContentType = uploadContentType;
	}

	//文件上传导入数据
	@Action("region_importData")
	public String importData(){
		
		//构建一个map结果对象
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		
		try {
			
			//存放区域列表
			List<Region> regionList = new ArrayList<Region>();
			//获取上传的文件(excel)，直接解析，
			//读取解析excle（和现实读取excel步骤一样）
			//1.打开excel工作簿
			//2007之前的格式xls
			HSSFWorkbook hssfWorkbook = new HSSFWorkbook(new FileInputStream(upload));
			//2007之后xlsx
//			XSSFWorkbook xssfWorkbook = new XSSFWorkbook(new FileInputStream(upload));
			//2.找到选择要读取的sheet，工作表
//			hssfWorkbook.getSheet("Sheet1");//根据名字读取
			HSSFSheet sheet = hssfWorkbook.getSheetAt(0);//根据索引读取
			//3.一行一行读取
			for (Row row : sheet) {
				
				//跳过第一行
				if(row.getRowNum()==0){
					continue;
				}
				//构建一个实体对象
				Region region = new Region();
				
				//从第二行开始读
				region.setId(row.getCell(0).getStringCellValue());//id,.一般都读取字符串
				region.setProvince(row.getCell(1).getStringCellValue());//省,.一般都读取字符串
				region.setCity(row.getCell(2).getStringCellValue());//市,.一般都读取字符串
				region.setDistrict(row.getCell(3).getStringCellValue());//区,.一般都读取字符串
				region.setPostcode(row.getCell(4).getStringCellValue());//邮编,.一般都读取字符串
				
				//添加到列表
				regionList.add(region);
				
				//有两个属性要填充值：简码和城市编码
				String province = region.getProvince();
				String city = region.getCity();
				String district = region.getDistrict();
				
				//简码
				String shortcodeStr=province.substring(0, province.length()-1)
						+city.substring(0, city.length()-1)
						+district.substring(0, district.length()-1);
				//转拼音
				String[] shortcodeStrArray = PinYin4jUtils.getHeadByString(shortcodeStr);
				//
				String shortcode = StringUtils.join(shortcodeStrArray, "");
				
				region.setShortcode(shortcode);
				
				//城市编码
				String citycode = PinYin4jUtils.hanziToPinyin(city.substring(0, city.length()-1), "");
				region.setCitycode(citycode);
				
				
			}
			
			
			//最终要保存数据save(对象)
			//调用业务层
			regionService.saveRegion(regionList);
			
			//成功
			resultMap.put("result", true);
			
		} catch (Exception e) {
			e.printStackTrace();
			//失败
			resultMap.put("result", false);
		} 
		
		//将map压入栈顶
		ActionContext.getContext().getValueStack().push(resultMap);
		
		return JSON;
		
	}
	
	//分页列表查询
	@Action("region_listPage")
	public String listPage(){
		//1.查询出数据
		//封装参数到pageable中
		Pageable pageable = new PageRequest(page-1, rows);
		
		Page<Region> pageResponse= regionService.findRegionListPage(pageable);
		//重新组装数据
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("total", pageResponse.getTotalElements());
		resultMap.put("rows", pageResponse.getContent());
		//2.放入值栈
		ActionContext.getContext().getValueStack().push(resultMap);
		
		//3.跳转到json类型结果集上
		return JSON;
	}
	
	
	//使用属性驱动来封装参数（分页的两个）
//	private int page;//页码
//	private int rows;//每页最大记录数
//	public void setPage(int page) {
//		this.page = page;
//	}
//	public void setRows(int rows) {
//		this.rows = rows;
//	}
	
	//查询（所有）区域列表
	@Action("region_listajax")
	public String listajax(){
		//获取请求的参数q的值
		String param=super.getFromParameter("q");
		List<Region> regionList=null;
		if(StringUtils.isBlank(param)){
			//调用业务层
			regionList= regionService.findRegionList();
		}else{
			regionList= regionService.findRegionList(param);
			
		}
		
		//压入栈顶
		ActionContext.getContext().getValueStack().push(regionList);
		
		return JSON;
	}

}
