package cn.itcast.bos.dao.user;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import cn.itcast.bos.domain.user.User;

//用户操作的dao层接口(无需实现类),必须继承jpaRepostory
public interface UserDAO extends JpaRepository<User, String> {
	
	//-----属性表达式方式（简单快捷，不用写sql）
	//精确匹配
	//要求：方法名必须满足findBy属性
	//返回值，必须是实体对象或实体对象列表，api会自动根据结果的类型，进行自动封装，但是，如果返回多个对象，必须用list，否则报错！
	public User findByUsername(String username);
	
	//模糊匹配
	public List<User> findByUsernameLike(String username);
	
	//--------------jpa的命名查询
	//根据用户名查询密码
	public String findPasswordByUsername(String username);
	
	//-----------@query注解
	//优先走@query注解
	//根据用户或密码查询
	//匿名占位符
//	@Query(value="from User where username =? and password =?")//hql
	@Query(value="select * from t_user where username=? and password =?",nativeQuery=true)//sql
	public User findUserByUsernameAndPassword(String username,String password);
	
	//命名占位符
	@Query("from User where username =:name and password =:pwd")
	public User findUserByUsernameAndPassword2(@Param("pwd")String password,@Param("name")String username);
	
	//jpa占位符
	//?1：自动匹配第一个参数的值，最大好处，一个参数可以用多次
	@Query("from User where username =?1 and password =?2 and username =?1")
	public User findUserByUsernameAndPassword3(String username,String password);
	
	//------------------------------
	//属性表达式
	public User findByUsernameAndPassword(String username,String password);
	
	//根据用户id修改密码
	@Query("update User set password =?2 where id =?1")
	@Modifying//让query具有修改的功能（增删改）
	public void updatePasswordById(String id,String password);
	
	

}
