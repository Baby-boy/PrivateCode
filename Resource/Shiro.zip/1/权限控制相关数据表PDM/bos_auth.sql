/*==============================================================*/
/* DBMS name:      ORACLE Version 10g                           */
/* Created on:     2016/2/23 14:28:46                           */
/*==============================================================*/


alter table t_auth_function
   drop constraint FK_T_AUTH_F_REFERENCE_T_AUTH_F;

alter table t_auth_role_function
   drop constraint FK_T_AUTH_R_REFERENCE_T_AUTH_F;

alter table t_auth_role_function
   drop constraint FK_T_AUTH_R_REFERENCE_T_AUTH_R;

alter table t_auth_user_role
   drop constraint FK_T_AUTH_U_REFERENCE_T_USER;

alter table t_auth_user_role
   drop constraint FK_T_AUTH_U_REFERENCE_T_AUTH_R;

drop table t_auth_function cascade constraints;

drop table t_auth_role cascade constraints;

drop table t_auth_role_function cascade constraints;

drop table t_auth_user_role cascade constraints;


/*==============================================================*/
/* Table: t_auth_function                                       */
/*==============================================================*/
create table t_auth_function  (
   id                   VARCHAR2(32)                    not null,
   name                 VARCHAR2(255),
   code                 VARCHAR2(255),
   description          VARCHAR2(255),
   page                 VARCHAR2(255),
   generatemenu         VARCHAR2(255),
   zindex               NUMBER,
   pid                  VARCHAR2(32),
   constraint PK_T_AUTH_FUNCTION primary key (id),
   constraint AK_KEY_2_T_AUTH_F unique (name)
);

comment on table t_auth_function is
'权限表';

comment on column t_auth_function.id is
'编号';

comment on column t_auth_function.name is
'名称';

comment on column t_auth_function.code is
'关键字';

comment on column t_auth_function.description is
'描述';

comment on column t_auth_function.page is
'路径';

comment on column t_auth_function.generatemenu is
'是否生成菜单';

comment on column t_auth_function.zindex is
'优先级';

comment on column t_auth_function.pid is
'父权限编号';

/*==============================================================*/
/* Table: t_auth_role                                           */
/*==============================================================*/
create table t_auth_role  (
   id                   VARCHAR2(32)                    not null,
   name                 VARCHAR2(255),
   code                 VARCHAR2(255),
   description          VARCHAR2(255),
   constraint PK_T_AUTH_ROLE primary key (id),
   constraint AK_KEY_2_T_AUTH_R unique (name)
);

comment on table t_auth_role is
'角色表';

comment on column t_auth_role.id is
'角色编号';

comment on column t_auth_role.name is
'角色名称';

comment on column t_auth_role.code is
'关键字';

comment on column t_auth_role.description is
'角色描述';

/*==============================================================*/
/* Table: t_auth_role_function                                  */
/*==============================================================*/
create table t_auth_role_function  (
   role_id              VARCHAR2(32)                    not null,
   function_id          VARCHAR2(32)                    not null,
   constraint PK_T_AUTH_ROLE_FUNCTION primary key (role_id, function_id)
);

comment on table t_auth_role_function is
'角色权限关系表';

comment on column t_auth_role_function.role_id is
'角色编号';

comment on column t_auth_role_function.function_id is
'权限编号';

/*==============================================================*/
/* Table: t_auth_user_role                                      */
/*==============================================================*/
create table t_auth_user_role  (
   user_id              VARCHAR2(32)                    not null,
   role_id              VARCHAR2(32)                    not null,
   constraint PK_T_AUTH_USER_ROLE primary key (user_id, role_id)
);

comment on table t_auth_user_role is
'用户角色关系表';

comment on column t_auth_user_role.user_id is
'用户编号';

comment on column t_auth_user_role.role_id is
'角色编号';


alter table t_auth_function
   add constraint FK_T_AUTH_F_REFERENCE_T_AUTH_F foreign key (pid)
      references t_auth_function (id);

alter table t_auth_role_function
   add constraint FK_T_AUTH_R_REFERENCE_T_AUTH_F foreign key (function_id)
      references t_auth_function (id);

alter table t_auth_role_function
   add constraint FK_T_AUTH_R_REFERENCE_T_AUTH_R foreign key (role_id)
      references t_auth_role (id);

alter table t_auth_user_role
   add constraint FK_T_AUTH_U_REFERENCE_T_USER foreign key (user_id)
      references t_user (id);

alter table t_auth_user_role
   add constraint FK_T_AUTH_U_REFERENCE_T_AUTH_R foreign key (role_id)
      references t_auth_role (id);

