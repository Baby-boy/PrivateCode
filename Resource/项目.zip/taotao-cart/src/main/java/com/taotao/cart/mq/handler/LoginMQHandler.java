package com.taotao.cart.mq.handler;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.taotao.cart.pojo.Cart;
import com.taotao.cart.service.CartRedisService;
import com.taotao.cart.service.CartService;

@Service
public class LoginMQHandler {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Autowired
    private CartRedisService cartRedisService;

    @Autowired
    private CartService cartService;

    public void execute(String msg) {
        try {
            JsonNode jsonNode = MAPPER.readTree(msg);
            Long userId = jsonNode.get("userId").asLong();
            if (!jsonNode.has("cookieCart")) {
                // 在未登录状态下没有数据，直接返回
                return;
            }
            String cookieCart = jsonNode.get("cookieCart").asText();
            List<Cart> carts = this.cartRedisService.queryCartList(cookieCart);
            if (carts == null || carts.isEmpty()) {
                // 在未登录状态下没有数据，直接返回
                return;
            }
            for (Cart cart : carts) {
                this.cartService.addItemToCart(cart.getItemId(), userId);
            }

            // 清空未登录状态下的购物车数据
            this.cartRedisService.clear(cookieCart);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
