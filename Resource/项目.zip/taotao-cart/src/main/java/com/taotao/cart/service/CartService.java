package com.taotao.cart.service;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.abel533.entity.Example;
import com.taotao.cart.bean.Item;
import com.taotao.cart.bean.User;
import com.taotao.cart.mapper.CartMapper;
import com.taotao.cart.pojo.Cart;
import com.taotao.cart.threadlocal.UserThreadLocal;

@Service
public class CartService {

    @Autowired
    private CartMapper cartMapper;

    @Autowired
    private ItemService itemService;

    public void addItemToCart(Long itemId, Long userId) {
        // 判断该商品在购物车中是否存在，如果存在数量相加，如果不存在，直接添加
        Cart record = new Cart();
        record.setItemId(itemId);
        record.setUserId(userId);
        Cart cart = this.cartMapper.selectOne(record);
        if (null == cart) {
            // 不存在
            cart = new Cart();
            cart.setItemId(itemId);
            cart.setNum(1); // TODO 未完成
            cart.setUserId(userId);
            cart.setCreated(new Date());
            cart.setUpdated(cart.getCreated());

            Item item = this.itemService.queryItemById(itemId);
            String[] images = StringUtils.split(item.getImage(), ',');
            if (null != images && images.length > 0) {
                cart.setItemImage(images[0]);
            }
            cart.setItemPrice(item.getPrice());
            cart.setItemTitle(item.getTitle());

            this.cartMapper.insert(cart);
        } else {
            // 存在
            cart.setNum(cart.getNum() + 1); // TODO 未完成
            cart.setUpdated(new Date());
            this.cartMapper.updateByPrimaryKeySelective(cart);
        }
    }

    public void addItemToCart(Long itemId) {
        User user = UserThreadLocal.get();
        this.addItemToCart(itemId, user.getId());

    }

    public List<Cart> queryCartList() {
        return this.queryCartList(UserThreadLocal.get().getId());
    }

    public List<Cart> queryCartList(Long userId) {
        Example example = new Example(Cart.class);
        example.createCriteria().andEqualTo("userId", userId);

        example.setOrderByClause("created DESC");
        return this.cartMapper.selectByExample(example);
    }

    public void updateNum(Long itemId, Integer num) {
        User user = UserThreadLocal.get();
        // 更新数据的条件
        Example example = new Example(Cart.class);
        example.createCriteria().andEqualTo("userId", user.getId()).andEqualTo("itemId", itemId);

        // 更新的数据
        Cart record = new Cart();
        record.setNum(num);
        record.setUpdated(new Date());
        this.cartMapper.updateByExampleSelective(record, example);
    }

    public void delete(Long itemId, Long userId) {
        Cart record = new Cart();
        record.setUserId(userId);
        record.setItemId(itemId);
        this.cartMapper.delete(record);
    }
    
    public void delete(Long itemId) {
        this.delete(itemId, UserThreadLocal.get().getId());
    }

}
