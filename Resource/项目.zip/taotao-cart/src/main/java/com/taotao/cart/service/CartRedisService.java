package com.taotao.cart.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.taotao.cart.bean.Item;
import com.taotao.cart.pojo.Cart;
import com.taotao.common.service.RedisService;
import com.taotao.common.utils.CookieUtils;

@Service
public class CartRedisService {

    private static final String COOKIE_NAME = "TT_CART";

    private static final Integer TIME = 60 * 60 * 24 * 30;

    @Autowired
    private ItemService itemService;

    @Autowired
    private RedisService redisService;

    private static final ObjectMapper MAPPER = new ObjectMapper();

    public void addItemToCart(Long itemId, HttpServletRequest request, HttpServletResponse response) {
        String key = CookieUtils.getCookieValue(request, COOKIE_NAME);
        if (StringUtils.isEmpty(key)) {
            // 生存一个key
            key = DigestUtils.md5Hex("" + System.currentTimeMillis() + itemId
                    + RandomUtils.nextInt(1000, 9999));
            // 写入到cookie中
            CookieUtils.setCookie(request, response, COOKIE_NAME, key, TIME);
        }
        // 判断该商品在购物车中是否存在，如果存在数量相加，如果不存在，直接添加
        String redisKey = getRedisKey(key);
        String cartStr = this.redisService.hget(redisKey, String.valueOf(itemId));
        Cart cart = null;
        if (StringUtils.isNotEmpty(cartStr)) {
            try {
                cart = MAPPER.readValue(cartStr, Cart.class);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (null == cart) {
            // 不存在
            cart = new Cart();
            cart.setItemId(itemId);
            cart.setCreated(new Date());
            cart.setUpdated(cart.getCreated());
            cart.setNum(1); // TODO 未完成

            Item item = this.itemService.queryItemById(itemId);
            String[] images = StringUtils.split(item.getImage(), ',');
            if (null != images && images.length > 0) {
                cart.setItemImage(images[0]);
            }
            cart.setItemPrice(item.getPrice());
            cart.setItemTitle(item.getTitle());
        } else {
            // 存在
            cart.setNum(cart.getNum() + 1); // TODO 未完成
            cart.setUpdated(new Date());
        }

        try {
            this.redisService.hset(redisKey, String.valueOf(itemId), MAPPER.writeValueAsString(cart), TIME);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Cart> queryCartList(String cookieCart) {
        String redisKey = getRedisKey(cookieCart);
        Map<String, String> map = this.redisService.hgetAll(redisKey);
        if (null == map || map.isEmpty()) {
            return new ArrayList<Cart>();
        }
        List<Cart> carts = new ArrayList<Cart>();
        for (String k : map.keySet()) {
            String json = map.get(k);
            Cart cart;
            try {
                cart = MAPPER.readValue(json, Cart.class);
                carts.add(cart);
            } catch (Exception e) {
                // 如果有异常，就忽略该数据
                e.printStackTrace();
            }
        }
        // 刷新数据的生存时间
        this.redisService.expire(redisKey, TIME);
        return carts;
    }

    public List<Cart> queryCartList(HttpServletRequest request, HttpServletResponse response) {
        String key = CookieUtils.getCookieValue(request, COOKIE_NAME);
        List<Cart> carts = this.queryCartList(key);
        // 按照创建时间倒序排序
        Collections.sort(carts, new Comparator<Cart>() {
            @Override
            public int compare(Cart o1, Cart o2) {
                return (int) (o2.getCreated().getTime() - o1.getCreated().getTime());
            }
        });

        CookieUtils.setCookie(request, response, COOKIE_NAME, key, TIME);
        return carts;
    }

    public void updateNum(Long itemId, Integer num, HttpServletRequest request) {
        String key = CookieUtils.getCookieValue(request, COOKIE_NAME);
        String redisKey = getRedisKey(key);
        String cartStr = this.redisService.hget(redisKey, String.valueOf(itemId));
        if (StringUtils.isEmpty(cartStr)) {
            return;
        }
        Cart cart = null;
        if (StringUtils.isNotEmpty(cartStr)) {
            try {
                cart = MAPPER.readValue(cartStr, Cart.class);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (null != cart) {
            cart.setNum(num);
            cart.setUpdated(new Date());

            try {
                this.redisService.hset(redisKey, String.valueOf(itemId), MAPPER.writeValueAsString(cart),
                        TIME);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    private String getRedisKey(String cookieKey){
        return "CART_" + cookieKey;
    }

    public void delete(Long itemId, HttpServletRequest request) {
        String key = CookieUtils.getCookieValue(request, COOKIE_NAME);
        String redisKey = getRedisKey(key);
        this.redisService.hdel(redisKey, String.valueOf(itemId));
    }

    public void clear(String cookieCart) {
        String redisKey = getRedisKey(cookieCart);
        this.redisService.del(redisKey);
    }

}
