package com.taotao.cart.mq.handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.taotao.cart.service.CartService;

@Service
public class OrderMQHandler {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Autowired
    private CartService cartService;

    public void execute(String msg) {
        try {
            JsonNode jsonNode = MAPPER.readTree(msg);
            Long userId = jsonNode.get("userId").asLong();
            ArrayNode itemIds = (ArrayNode) jsonNode.get("itemIds");
            // TODO 这样做不好，应该in删除
            for (JsonNode itemId : itemIds) {
                this.cartService.delete(itemId.asLong(), userId);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
