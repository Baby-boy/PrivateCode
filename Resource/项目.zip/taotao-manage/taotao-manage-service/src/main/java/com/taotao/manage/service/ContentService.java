package com.taotao.manage.service;

import org.springframework.stereotype.Service;

import com.taotao.manage.pojo.Content;

@Service
public class ContentService extends BaseService<Content>{

}
