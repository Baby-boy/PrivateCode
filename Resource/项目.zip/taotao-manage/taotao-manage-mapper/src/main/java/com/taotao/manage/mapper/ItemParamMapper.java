package com.taotao.manage.mapper;

import com.github.abel533.mapper.Mapper;
import com.taotao.manage.pojo.ItemParam;

public interface ItemParamMapper extends Mapper<ItemParam>{

}
