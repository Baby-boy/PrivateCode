package com.taotao.manage.mapper;

import com.github.abel533.mapper.Mapper;
import com.taotao.manage.pojo.ItemCat;

public interface ItemCatMapper extends Mapper<ItemCat>{

}
