package com.glanway.hr.dms.entity.schedule;

import com.glanway.hr.dms.entity.BaseEntity;

public class Schedule extends BaseEntity {

	private static final long serialVersionUID = 5447636263981801664L;

	private String employeeCode;// 职员代码

	private Short year;// 排班年份

	private Short month;// 排班月份

	private Long day1;// 每天排班任务

	private Long day2;

	private Long day3;

	private Long day4;

	private Long day5;

	private Long day6;

	private Long day7;

	private Long day8;

	private Long day9;

	private Long day10;

	private Long day12;

	private Long day13;

	private Long day14;

	private Long day15;

	private Long day16;

	private Long day17;

	private Long day18;

	private Long day19;

	private Long day20;

	private Long day21;

	private Long day22;

	private Long day23;

	private Long day24;

	private Long day25;

	private Long day26;

	private Long day27;

	private Long day28;

	private Long day29;

	private Long day30;

	private Long day31;

	public String getEmployeeCode() {
		return employeeCode;
	}

	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode == null ? null : employeeCode.trim();
	}

	public Short getYear() {
		return year;
	}

	public void setYear(Short year) {
		this.year = year;
	}

	public Short getMonth() {
		return month;
	}

	public void setMonth(Short month) {
		this.month = month;
	}

	public Long getDay1() {
		return day1;
	}

	public void setDay1(Long day1) {
		this.day1 = day1;
	}

	public Long getDay2() {
		return day2;
	}

	public void setDay2(Long day2) {
		this.day2 = day2;
	}

	public Long getDay3() {
		return day3;
	}

	public void setDay3(Long day3) {
		this.day3 = day3;
	}

	public Long getDay4() {
		return day4;
	}

	public void setDay4(Long day4) {
		this.day4 = day4;
	}

	public Long getDay5() {
		return day5;
	}

	public void setDay5(Long day5) {
		this.day5 = day5;
	}

	public Long getDay6() {
		return day6;
	}

	public void setDay6(Long day6) {
		this.day6 = day6;
	}

	public Long getDay7() {
		return day7;
	}

	public void setDay7(Long day7) {
		this.day7 = day7;
	}

	public Long getDay8() {
		return day8;
	}

	public void setDay8(Long day8) {
		this.day8 = day8;
	}

	public Long getDay9() {
		return day9;
	}

	public void setDay9(Long day9) {
		this.day9 = day9;
	}

	public Long getDay10() {
		return day10;
	}

	public void setDay10(Long day10) {
		this.day10 = day10;
	}

	public Long getDay12() {
		return day12;
	}

	public void setDay12(Long day12) {
		this.day12 = day12;
	}

	public Long getDay13() {
		return day13;
	}

	public void setDay13(Long day13) {
		this.day13 = day13;
	}

	public Long getDay14() {
		return day14;
	}

	public void setDay14(Long day14) {
		this.day14 = day14;
	}

	public Long getDay15() {
		return day15;
	}

	public void setDay15(Long day15) {
		this.day15 = day15;
	}

	public Long getDay16() {
		return day16;
	}

	public void setDay16(Long day16) {
		this.day16 = day16;
	}

	public Long getDay17() {
		return day17;
	}

	public void setDay17(Long day17) {
		this.day17 = day17;
	}

	public Long getDay18() {
		return day18;
	}

	public void setDay18(Long day18) {
		this.day18 = day18;
	}

	public Long getDay19() {
		return day19;
	}

	public void setDay19(Long day19) {
		this.day19 = day19;
	}

	public Long getDay20() {
		return day20;
	}

	public void setDay20(Long day20) {
		this.day20 = day20;
	}

	public Long getDay21() {
		return day21;
	}

	public void setDay21(Long day21) {
		this.day21 = day21;
	}

	public Long getDay22() {
		return day22;
	}

	public void setDay22(Long day22) {
		this.day22 = day22;
	}

	public Long getDay23() {
		return day23;
	}

	public void setDay23(Long day23) {
		this.day23 = day23;
	}

	public Long getDay24() {
		return day24;
	}

	public void setDay24(Long day24) {
		this.day24 = day24;
	}

	public Long getDay25() {
		return day25;
	}

	public void setDay25(Long day25) {
		this.day25 = day25;
	}

	public Long getDay26() {
		return day26;
	}

	public void setDay26(Long day26) {
		this.day26 = day26;
	}

	public Long getDay27() {
		return day27;
	}

	public void setDay27(Long day27) {
		this.day27 = day27;
	}

	public Long getDay28() {
		return day28;
	}

	public void setDay28(Long day28) {
		this.day28 = day28;
	}

	public Long getDay29() {
		return day29;
	}

	public void setDay29(Long day29) {
		this.day29 = day29;
	}

	public Long getDay30() {
		return day30;
	}

	public void setDay30(Long day30) {
		this.day30 = day30;
	}

	public Long getDay31() {
		return day31;
	}

	public void setDay31(Long day31) {
		this.day31 = day31;
	}

}