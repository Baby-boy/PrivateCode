package com.glanway.hr.dms.dao.schedule;

import org.apache.ibatis.annotations.Param;

import com.glanway.hr.dms.dao.BaseDao;
import com.glanway.hr.dms.entity.schedule.Schedule;

public interface ScheduleDao extends BaseDao<Schedule> {

	/** 根据职员代码和年月查询排班表中是否已经存在排班信息 */
	public Schedule findSchedule(@Param("employeeCode") Long employeeId, @Param("year") String year,
			@Param("month") String month);

}