package com.glanway.hr.dms.service.schedule;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.glanway.hr.dms.dao.schedule.ScheduleDao;
import com.glanway.hr.dms.dao.schedule.SchedulingDao;
import com.glanway.hr.dms.entity.schedule.Schedule;
import com.glanway.hr.dms.entity.schedule.Scheduling;
import com.glanway.hr.dms.utils.TimeUtil;

@Component("scheduleProcessor")
public class ScheduleProcessor implements ItemProcessor<Scheduling, Schedule> {

	@Autowired
	private SchedulingDao schedulingDao;

	@Autowired
	private ScheduleDao scheduleDao;

	@Override
	public Schedule process(Scheduling scheduling) throws Exception {
		Schedule schedule = scheduleDao.findSchedule(scheduling.getEmployeeId(), TimeUtil.getYear(),
				TimeUtil.getMonth());
		if (null != schedule) {
			return null;
		} else {
			schedule = new Schedule();
			schedule.setEmployeeCode(scheduling.getEmployeeId().toString());
			schedule.setYear(scheduling.getYear());
			schedule.setMonth(scheduling.getMonth());
			schedule.setDay1(scheduling.getDay1());
		}

		return schedule;
	}

}
