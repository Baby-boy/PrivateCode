package com.glanway.hr.dms.dao.schedule;

import com.glanway.hr.dms.dao.BaseDao;
import com.glanway.hr.dms.entity.schedule.Scheduling;

public interface SchedulingDao extends BaseDao<Scheduling> {

	public Scheduling findSchedulingList();
}