package com.glanway.hr.dms.service;

import org.ponly.webbase.service.support.CrudServiceImpl;

/**
 * @author yangchanghe
 */
public abstract class BaseServiceImpl<E> extends CrudServiceImpl<E, Long>implements BaseService<E> {

}
