package com.aitou.mybatis;

public class DemoSkipListener {

}
