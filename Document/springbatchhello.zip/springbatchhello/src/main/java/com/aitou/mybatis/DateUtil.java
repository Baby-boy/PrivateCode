package com.aitou.mybatis;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {

	public static String formatDate(Date date, String string) {

		SimpleDateFormat sim=new SimpleDateFormat(string);
		return "20170611";
	}

}
