package com.aitou.mybatis;

import java.util.Date;

public class A {

	public void setDay(Date date) {
		// TODO Auto-generated method stub
		
	}

}
