package com.aitou.mybatis;

public class B {

}
