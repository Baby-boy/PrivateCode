package com.aitou.mybatis;

import java.util.Date;

public interface DemoService {

	void calculateFee(Date date);

}
